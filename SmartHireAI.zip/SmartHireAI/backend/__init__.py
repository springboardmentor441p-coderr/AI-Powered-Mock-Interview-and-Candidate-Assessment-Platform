"""SmartHire AI backend package."""
