import { useState, useEffect } from 'react';
import './App.css';

const getCandidateNameFromEmail = (email) => {
  const localPart = email.split('@')[0] || '';
  const words = localPart
    .replace(/[._-]+/g, ' ')
    .split(/\s+/)
    .filter(Boolean);
  if (!words.length) return 'Candidate';
  return words.map((word) => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
};

const features = [
  {
    title: 'Resume intelligence',
    description: 'Upload a CV and let AI extract skills, experience, and strengths in seconds.',
  },
  {
    title: 'Adaptive interviews',
    description: 'Practice HR, technical, behavioral, and aptitude rounds with realistic simulations.',
  },
  {
    title: 'Actionable feedback',
    description: 'Receive detailed scoring with communication, confidence, and professionalism insights.',
  },
];

const metrics = [
  { value: '90+', label: 'Interview readiness score' },
  { value: '4x', label: 'Faster skill practice' },
  { value: '24/7', label: 'AI coaching availability' },
  { value: '100%', label: 'Personalized guidance' },
];

const dashboardStats = [
  { label: 'Mock sessions', value: '12' },
  { label: 'Confidence trend', value: '+18%' },
  { label: 'Weakest skill', value: 'System design' },
];

const upcomingRounds = ['HR behavioral', 'Technical coding', 'Leadership round'];

function App() {
  const [view, setView] = useState('landing');
  const [authMode, setAuthMode] = useState('login');
  const [theme, setTheme] = useState('dark');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [resumeName, setResumeName] = useState('');
  const [resumeStatus, setResumeStatus] = useState('');
  const [candidateName, setCandidateName] = useState('Candidate');
  const [mockRoundStarted, setMockRoundStarted] = useState(false);
  const [mockRoundOpen, setMockRoundOpen] = useState(false);
  const [candidates, setCandidates] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(5);
  const [hasNext, setHasNext] = useState(false);

  const handleAuthSubmit = (event) => {
    event.preventDefault();
    const name = getCandidateNameFromEmail(email);
    setCandidateName(name);
    setView('dashboard');
  };

  const handleResumeUpload = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const maxSizeInBytes = 1_500_000;
    if (file.size > maxSizeInBytes) {
      setResumeStatus('Resume too large. Please keep it under 1.5 MB for the demo.');
      return;
    }

    // send the file as FormData to backend /candidates/upload
    setResumeName(file.name);
    const form = new FormData();
    form.append('email', email || `${candidateName.replace(/\s+/g, '.').toLowerCase()}@example.com`);
    form.append('file', file);

    try {
      const res = await fetch('http://127.0.0.1:8000/candidates/upload', {
        method: 'POST',
        body: form,
      });
      if (!res.ok) throw new Error(await res.text());
      const json = await res.json();
      const savedName = getCandidateNameFromEmail(email || `${candidateName.replace(/\s+/g, '.').toLowerCase()}@example.com`);
      setResumeStatus(`Uploaded: ${json.name} (${json.resume_name || 'no file name'})`);
      setCandidateName(savedName);
      setMockRoundStarted(true);
        setMockRoundOpen(true);
      fetchCandidates();
    } catch (err) {
      setResumeStatus('Upload failed: ' + String(err));
    }
  };

  const fetchCandidates = async () => {
    try {
      const limit = pageSize;
      const offset = (page - 1) * pageSize;
      const q = encodeURIComponent(searchQuery || '');
      const url = `http://127.0.0.1:8000/candidates/all?limit=${limit}&offset=${offset}${q ? `&q=${q}` : ''}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error(await res.text());
      const data = await res.json();
      setCandidates(data);
      setHasNext(data.length === pageSize);
    } catch (err) {
      // ignore for demo
      console.error('fetchCandidates error', err);
    }
  };

  // fetch candidates when dashboard opens or when page/search change
  useEffect(() => {
    if (view === 'dashboard') fetchCandidates();
  }, [view, page, searchQuery]);

  return (
    <div className={`app-shell theme-${theme}`}>
      <nav className="navbar">
        <div className="brand">SmartHire AI</div>
        <div className="nav-actions">
          <button
            className="icon-button"
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            type="button"
          >
            {theme === 'dark' ? '☀️ Light' : '🌙 Dark'}
          </button>
          <button className="text-button" onClick={() => setView('landing')} type="button">
            Home
          </button>
          <button className="text-button" onClick={() => setView('auth')} type="button">
            Sign in
          </button>
          <button className="text-button primary" onClick={() => setView('dashboard')} type="button">
            Dashboard
          </button>
        </div>
      </nav>

      {view === 'landing' && (
        <>
          <header className="hero">
            <div className="hero-copy">
              <h1>Train for interviews with intelligent AI coaching.</h1>
              <p>
                SmartHire AI helps candidates sharpen their communication, confidence, and technical
                depth through immersive mock interviews and real-time evaluation.
              </p>
              <div className="hero-actions">
                <button
                  className="button button-primary"
                  onClick={() => {
                    setAuthMode('register');
                    setView('auth');
                  }}
                  type="button"
                >
                  Create account
                </button>
                <button
                  className="button button-secondary"
                  onClick={() => setView('dashboard')}
                  type="button"
                >
                  Open dashboard
                </button>
              </div>
              <p>Built for students, job seekers, and hiring teams.</p>
            </div>

            <div className="hero-card">
              <h2>What the platform delivers</h2>
              <ul>
                <li>✓ AI-generated interview questions</li>
                <li>✓ Speech, emotion, and eye-contact analysis</li>
                <li>✓ Weighted scoring and detailed reports</li>
                <li>✓ Role-based dashboards for candidates and recruiters</li>
              </ul>
            </div>
          </header>

          <section id="features" className="section">
            <h2 className="section-title">Core capabilities</h2>
            <div className="card-grid">
              {features.map((feature) => (
                <article className="info-card" key={feature.title}>
                  <h3>{feature.title}</h3>
                  <p>{feature.description}</p>
                </article>
              ))}
            </div>
          </section>

          <section className="section">
            <h2 className="section-title">Performance insights</h2>
            <div className="metric-grid">
              {metrics.map((metric) => (
                <article className="metric-card" key={metric.label}>
                  <div className="value">{metric.value}</div>
                  <p>{metric.label}</p>
                </article>
              ))}
            </div>
          </section>

          <section id="launch" className="section">
            <div className="cta">
              <h2>Ready to launch your interview journey?</h2>
              <p>Sign in, upload your resume, and start your AI-powered mock interview today.</p>
              <button className="button button-primary" onClick={() => setView('auth')} type="button">
                Start now
              </button>
            </div>
          </section>
        </>
      )}

      {view === 'auth' && (
        <section className="section auth-section">
          <div className="auth-panel">
            <div className="auth-switch">
              <button
                className={authMode === 'login' ? 'active' : ''}
                onClick={() => setAuthMode('login')}
                type="button"
              >
                Login
              </button>
              <button
                className={authMode === 'register' ? 'active' : ''}
                onClick={() => setAuthMode('register')}
                type="button"
              >
                Register
              </button>
            </div>

            <h2>{authMode === 'login' ? 'Welcome back' : 'Create your account'}</h2>
            <p>
              {authMode === 'login'
                ? 'Continue your interview prep and pick up from your latest session.'
                : 'Join SmartHire AI and begin your first mock interview.'}
            </p>

            <form className="auth-form" onSubmit={handleAuthSubmit}>
              <label>
                Email
                <input
                  type="email"
                  placeholder="you@example.com"
                  value={email}
                  onChange={(event) => setEmail(event.target.value)}
                  required
                />
              </label>
              <label>
                Password
                <input
                  type="password"
                  placeholder="At least 8 characters"
                  value={password}
                  onChange={(event) => setPassword(event.target.value)}
                  required
                />
              </label>
              <button className="button button-primary" type="submit">
                {authMode === 'login' ? 'Sign in' : 'Create account'}
              </button>
            </form>
          </div>
        </section>
      )}

      {view === 'dashboard' && (
        <section className="section dashboard-section">
          <div className="dashboard-card hero-card">
            <div className="dashboard-header">
              <div>
                <p className="pill">Candidate dashboard</p>
                <h2>Great progress, {candidateName}.</h2>
                <p>Your interview confidence is trending upward each week.</p>
              </div>
              <button
                className="button button-primary"
                type="button"
                onClick={() => {
                  setMockRoundStarted(true);
                  setMockRoundOpen(true);
                }}
              >
                {mockRoundStarted ? 'Mock round started' : 'Start new mock round'}
              </button>
            </div>
            {mockRoundOpen && (
              <div className="dashboard-card mock-round-card">
                <h3>Mock interview session</h3>
                <p>Your mock round is now live. Answer the next question to continue the demo.</p>
                <ol>
                  <li>Describe a recent project where you solved a tough problem.</li>
                  <li>What is your strongest technical skill, and how have you applied it?</li>
                  <li>How do you prepare for behavioral interview questions?</li>
                </ol>
                <button className="button button-secondary" type="button" onClick={() => setMockRoundOpen(false)}>
                  Close mock round
                </button>
              </div>
            )}

            <div className="dashboard-grid">
              {dashboardStats.map((stat) => (
                <article className="info-card" key={stat.label}>
                  <h3>{stat.value}</h3>
                  <p>{stat.label}</p>
                </article>
              ))}
            </div>
          </div>

          <div className="dashboard-grid lower-grid">
            <article className="dashboard-card">
              <h3>Weekly progress</h3>
              <div className="progress-list">
                <div>
                  <span>Communication</span>
                  <div className="progress-bar"><div style={{ width: '84%' }} /></div>
                </div>
                <div>
                  <span>Technical clarity</span>
                  <div className="progress-bar"><div style={{ width: '76%' }} /></div>
                </div>
                <div>
                  <span>Professionalism</span>
                  <div className="progress-bar"><div style={{ width: '92%' }} /></div>
                </div>
              </div>
            </article>

            <article className="dashboard-card">
              <h3>Resume upload demo</h3>
              <p>Upload a resume to test the candidate profile flow.</p>
              <label className="upload-box">
                <input type="file" accept=".pdf,.doc,.docx,.txt" onChange={handleResumeUpload} />
                <span>Choose file</span>
              </label>
              <p className="upload-meta">
                {resumeName ? `Selected: ${resumeName}` : 'PDF, DOCX, TXT supported'}
              </p>
              {resumeStatus && <p className="upload-meta">{resumeStatus}</p>}
              <p className="upload-meta">Candidate name: {candidateName}</p>
              {mockRoundStarted && (
                <p className="upload-meta">Mock round started — launching your next interview session.</p>
              )}
            </article>
            <article className="dashboard-card">
              <h3>Saved candidates</h3>
              <div className="candidate-controls" style={{ display: 'flex', gap: '8px', alignItems: 'center', marginBottom: '8px' }}>
                <input
                  type="search"
                  placeholder="Search candidates..."
                  value={searchQuery}
                  onChange={(e) => { setSearchQuery(e.target.value); setPage(1); }}
                />
                <button className="button" onClick={() => { setPage(1); fetchCandidates(); }} type="button">Refresh</button>
                <div className="pagination" style={{ marginLeft: 'auto', display: 'flex', gap: '8px', alignItems: 'center' }}>
                  <button className="button" disabled={page === 1} onClick={() => setPage((p) => Math.max(1, p - 1))} type="button">Prev</button>
                  <span>Page {page}</span>
                  <button className="button" disabled={!hasNext} onClick={() => setPage((p) => p + 1)} type="button">Next</button>
                </div>
              </div>

              {candidates.length === 0 ? (
                <p className="upload-meta">No candidates yet.</p>
              ) : (
                <ul>
                  {candidates.map((c) => (
                    <li key={c.email}>
                      <strong>{c.name}</strong> — {c.email} {c.resume_name ? `(${c.resume_name})` : ''}
                    </li>
                  ))}
                </ul>
              )}
            </article>
          </div>
        </section>
      )}
    </div>
  );
}

export default App;
