// ======================================================
// SmartHire AI - Voice V2
// ======================================================

console.log("================================");
console.log("🔊 SmartHire AI Voice V2");
console.log("================================");


// ======================================================
// SPEAK QUESTION
// ======================================================

async function speakQuestion(question) {

    return new Promise(async (resolve) => {

        let audio = null;
        let finished = false;

        try {

            // --------------------------------------------------
            // Validate question
            // --------------------------------------------------

            if (
                !question ||
                typeof question !== "string" ||
                !question.trim()
            ) {

                console.error(
                    "❌ Cannot speak empty question."
                );

                resolve();
                return;
            }

            question = question.trim();


            console.log(
                "🤖 Generating AI voice for:",
                question
            );


            // --------------------------------------------------
            // Status elements
            // --------------------------------------------------

            const status =
                document.getElementById("status");

            const micAnimation =
                document.getElementById("micAnimation");


            if (status) {

                status.innerHTML =
                    "🤖 AI is preparing the question...";
            }


            if (micAnimation) {

                micAnimation.style.display =
                    "none";
            }


            // --------------------------------------------------
            // Save current question globally
            //
            // This is useful for speech_v2.js
            // --------------------------------------------------

            window.currentQuestion =
                question;

            window.currentDisplayedQuestion =
                question;


            console.log(
                "🌐 Voice current question:",
                window.currentQuestion
            );


            // --------------------------------------------------
            // Call backend
            // --------------------------------------------------

            const response =
                await fetch(
                    "http://127.0.0.1:8000/generate_voice",
                    {
                        method: "POST",

                        headers: {
                            "Content-Type":
                                "application/json"
                        },

                        body:
                            JSON.stringify({
                                text: question
                            })
                    }
                );


            // --------------------------------------------------
            // Check backend response
            // --------------------------------------------------

            if (!response.ok) {

                let errorText = "";

                try {

                    errorText =
                        await response.text();

                }

                catch (error) {

                    errorText =
                        "Unable to read server error.";
                }


                throw new Error(
                    "AI voice generation failed. " +
                    "Status: " +
                    response.status +
                    " " +
                    errorText
                );
            }


            // --------------------------------------------------
            // Parse JSON
            // --------------------------------------------------

            const data =
                await response.json();


            console.log(
                "🤖 AI voice response:",
                data
            );

            // Save the exact AI audio filename for the answer record.
            localStorage.setItem(
                "lastAIAudio",
                String(data.audio_file)
            );

            console.log(
                "💾 Last AI audio saved:",
                data.audio_file
            );


            // --------------------------------------------------
            // Validate audio file
            // --------------------------------------------------

            if (
                !data ||
                !data.audio_file
            ) {

                throw new Error(
                    "Backend did not return an audio file."
                );
            }


            // --------------------------------------------------
            // Create audio URL
            // --------------------------------------------------

            const audioUrl =
                "http://127.0.0.1:8000/interview_audio/" +
                encodeURIComponent(
                    data.audio_file
                );


            console.log(
                "🔊 Playing AI voice:",
                audioUrl
            );


            // --------------------------------------------------
            // Create audio player
            // --------------------------------------------------

            audio =
                new Audio();


            audio.src =
                audioUrl;

            audio.volume =
                1.0;

            audio.preload =
                "auto";


            // --------------------------------------------------
            // AI voice starts
            // --------------------------------------------------

            audio.onplay =
                function () {

                    console.log(
                        "🤖 AI voice started"
                    );


                    const status =
                        document.getElementById(
                            "status"
                        );


                    const micAnimation =
                        document.getElementById(
                            "micAnimation"
                        );


                    if (status) {

                        status.innerHTML =
                            "🤖 AI is asking the question...";
                    }


                    if (micAnimation) {

                        micAnimation.style.display =
                            "none";
                    }
                };


            // --------------------------------------------------
            // AI voice finished
            // --------------------------------------------------

            audio.onended =
                function () {

                    if (finished) {

                        return;
                    }


                    finished =
                        true;


                    console.log(
                        "🤖 AI voice finished"
                    );


                    // ------------------------------------------------
                    // Update status
                    // ------------------------------------------------

                    const status =
                        document.getElementById(
                            "status"
                        );


                    if (status) {

                        status.innerHTML =
                            "🎤 Listening... Speak your answer.";
                    }


                    // ------------------------------------------------
                    // IMPORTANT
                    //
                    // Start speech recorder through the GLOBAL
                    // function from speech_v2.js
                    // ------------------------------------------------

                    if (
                        typeof window.startListening ===
                        "function"
                    ) {

                        console.log(
                            "🎤 Starting candidate listening..."
                        );


                        try {

                            window.startListening();

                        }

                        catch (error) {

                            console.error(
                                "❌ Error starting speech recording:",
                                error
                            );
                        }

                    }

                    else {

                        console.error(
                            "❌ window.startListening() is not available."
                        );

                        if (status) {

                            status.innerHTML =
                                "❌ Speech recorder is not available.";
                        }
                    }


                    resolve();
                };


            // --------------------------------------------------
            // Audio loading error
            // --------------------------------------------------

            audio.onerror =
                function (error) {

                    if (finished) {

                        return;
                    }


                    finished =
                        true;


                    console.error(
                        "❌ AI audio playback error:",
                        error
                    );


                    const status =
                        document.getElementById(
                            "status"
                        );


                    if (status) {

                        status.innerHTML =
                            "⚠️ AI voice failed. Starting microphone...";
                    }


                    // ------------------------------------------------
                    // If voice fails, DON'T stop interview.
                    // Start candidate recording directly.
                    // ------------------------------------------------

                    if (
                        typeof window.startListening ===
                        "function"
                    ) {

                        console.log(
                            "🎤 Starting microphone because AI voice failed..."
                        );


                        try {

                            window.startListening();

                        }

                        catch (error) {

                            console.error(
                                "❌ Could not start microphone:",
                                error
                            );
                        }
                    }


                    resolve();
                };


            // --------------------------------------------------
            // Audio play promise
            // --------------------------------------------------

            try {

                await audio.play();

            }

            catch (playError) {

                console.error(
                    "❌ Browser could not play AI voice:",
                    playError
                );


                if (!finished) {

                    finished =
                        true;


                    const status =
                        document.getElementById(
                            "status"
                        );


                    if (status) {

                        status.innerHTML =
                            "⚠️ AI voice could not play. Starting microphone...";
                    }


                    // ------------------------------------------------
                    // Fallback
                    // ------------------------------------------------

                    if (
                        typeof window.startListening ===
                        "function"
                    ) {

                        console.log(
                            "🎤 Starting microphone fallback..."
                        );


                        try {

                            window.startListening();

                        }

                        catch (error) {

                            console.error(
                                "❌ Microphone fallback failed:",
                                error
                            );
                        }
                    }


                    resolve();
                }
            }

        }

        catch (error) {

            console.error(
                "❌ AI voice error:",
                error
            );


            const status =
                document.getElementById(
                    "status"
                );


            if (status) {

                status.innerHTML =
                    "⚠️ AI voice failed. Starting microphone...";
            }


            // --------------------------------------------------
            // IMPORTANT FALLBACK
            // --------------------------------------------------

            if (
                !finished &&
                typeof window.startListening ===
                    "function"
            ) {

                finished =
                    true;


                console.log(
                    "🎤 Starting microphone after voice error..."
                );


                try {

                    window.startListening();

                }

                catch (microphoneError) {

                    console.error(
                        "❌ Microphone start failed:",
                        microphoneError
                    );
                }
            }


            resolve();
        }

    });
}


// ======================================================
// MAKE FUNCTION AVAILABLE GLOBALLY
// ======================================================

window.speakQuestion =
    speakQuestion;


// ======================================================
// FILE LOADED
// ======================================================

console.log(
    "✅ voice_v2.js loaded successfully."
);

console.log(
    "👉 speakQuestion available:",
    typeof window.speakQuestion === "function"
);

console.log(
    "👉 startListening available:",
    typeof window.startListening === "function"
);