const API = "http://127.0.0.1:8000";

async function uploadResume() {

    const fileInput = document.getElementById("resumeFile");

    if (fileInput.files.length === 0) {
        alert("Please choose a PDF.");
        return;
    }

    const formData = new FormData();
    formData.append("file", fileInput.files[0]);

    try {

        const response = await fetch(API + "/upload_resume", {
            method: "POST",
            body: formData
        });

        const data = await response.json();

        console.log(data);

        // Save complete resume data
        localStorage.setItem(
            "resumeData",
            JSON.stringify(data.resume_data)
        );

        document.getElementById("result").innerHTML =
            JSON.stringify(data, null, 2);

        alert("Resume Uploaded Successfully!");

    } catch (err) {

        console.log(err);
        alert("Resume Upload Failed.");

    }

}