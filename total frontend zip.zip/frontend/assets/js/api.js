const API = "http://127.0.0.1:8000";

// --------------------
// Upload Resume
// --------------------
async function uploadResume() {

    const fileInput = document.getElementById("resumeFile");

    if (fileInput.files.length === 0) {
        alert("Please select a PDF Resume.");
        return;
    }

    const formData = new FormData();
    formData.append("file", fileInput.files[0]);

    try {

        const response = await fetch(API + "/upload_resume", {
            method: "POST",
            body: formData
        });

        const data = await response.json();

        if (response.ok) {

            document.getElementById("result").textContent =
                JSON.stringify(data, null, 4);

            // Store data for dashboard
            localStorage.setItem("resumeData", JSON.stringify(data.resume_data));

alert("Resume Uploaded Successfully!");

// Automatically open interview page
window.location.href =
    "http://127.0.0.1:8000/interview_v2";

        } else {

            alert(data.detail);

        }

    } catch (error) {

        alert("Server Error");

        console.log(error);

    }

}