let warningCount = 0;
let interviewCancelled = false;

function showWarning(message) {

    if (interviewCancelled) return;

    warningCount++;

    alert("⚠ Warning " + warningCount + "\n\n" + message);

    if (warningCount >= 2) {

        interviewCancelled = true;

        alert("❌ Interview Cancelled due to suspicious activity.");

        document.getElementById("status").innerHTML =
            "<h2 style='color:red'>Interview Cancelled</h2>";

        document.getElementById("nextBtn").disabled = true;

        window.location.href = "report.html";
    }
}

async function startCameraMonitoring() {

    const video = document.createElement("video");

    video.setAttribute("autoplay", true);

    video.style.display = "none";

    document.body.appendChild(video);

    const stream = await navigator.mediaDevices.getUserMedia({

        video: true

    });

    video.srcObject = stream;

    const faceDetector =
        new FaceDetector({
            fastMode: true,
            maxDetectedFaces: 5
        });

    async function detect() {

        if (interviewCancelled) return;

        try {

            const faces =
                await faceDetector.detect(video);

            if (faces.length === 0) {

                showWarning("Face not detected.");

            }

            else if (faces.length > 1) {

                showWarning("Multiple persons detected.");

            }

            else {

                const box = faces[0].boundingBox;

                const centerX =
                    box.x + box.width / 2;

                const width =
                    video.videoWidth;

                if (centerX < width * 0.30) {

                    showWarning("Please look at the screen.");

                }

                if (centerX > width * 0.70) {

                    showWarning("Please look at the screen.");

                }

            }

        }

        catch(e){

            console.log(e);

        }

        setTimeout(detect,3000);

    }

    detect();

}

window.onload=function(){

    startCameraMonitoring();

}