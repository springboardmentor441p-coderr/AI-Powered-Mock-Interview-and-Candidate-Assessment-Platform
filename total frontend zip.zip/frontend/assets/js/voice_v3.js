function speakQuestion(question) {

    return new Promise((resolve) => {

        // Stop any previous speech
        window.speechSynthesis.cancel();

        const speech = new SpeechSynthesisUtterance();

        speech.text = question;
        speech.lang = "en-US";
        speech.rate = 1;
        speech.pitch = 1;
        speech.volume = 1;

        speech.onstart = function () {

            document.getElementById("status").innerHTML =
                "🤖 AI is asking the question...";

            document.getElementById("micAnimation").style.display =
                "none";

        };

        speech.onend = function () {

            document.getElementById("status").innerHTML =
                "🎤 Listening...";

            document.getElementById("micAnimation").style.display =
                "block";

            // Microphone will start here in the next step
            if (typeof startListening === "function") {
                startListening();
            }

            resolve();

        };

        window.speechSynthesis.speak(speech);

    });

}