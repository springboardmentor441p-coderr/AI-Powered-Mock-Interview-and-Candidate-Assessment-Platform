const resumeData =
JSON.parse(localStorage.getItem("resumeData"));

console.log(resumeData);