let faceMesh;

let previousNoseX = 0;
let previousNoseY = 0;

let headWarnings = 0;

const video = document.getElementById("video");
const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");

let model;
let warningCount = 0;

async function startCamera() {

    const stream = await navigator.mediaDevices.getUserMedia({
        video: true
    });

    video.srcObject = stream;

    video.onloadedmetadata = async () => {

        video.play();

        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;

        model = await cocoSsd.load();
        faceMesh = new FaceMesh({

locateFile: (file) => {

return `https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh/${file}`;

}

});

faceMesh.setOptions({

maxNumFaces:1,

refineLandmarks:true,

minDetectionConfidence:0.5,

minTrackingConfidence:0.5

});

faceMesh.onResults(onFaceResults);

detectHead();

        detectObjects();

    };

}

async function detectObjects() {

    const predictions = await model.detect(video);

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    predictions.forEach(prediction => {

        ctx.beginPath();

        ctx.rect(
            prediction.bbox[0],
            prediction.bbox[1],
            prediction.bbox[2],
            prediction.bbox[3]
        );

        ctx.lineWidth = 2;
        ctx.strokeStyle = "red";
        ctx.stroke();

        ctx.fillStyle = "red";

        ctx.fillText(
            prediction.class,
            prediction.bbox[0],
            prediction.bbox[1] - 5
        );

    });

    requestAnimationFrame(detectObjects);

}

startCamera();
async function detectHead(){

await faceMesh.send({

image:video

});

requestAnimationFrame(detectHead);

}
function onFaceResults(results) {

    if (!results.multiFaceLandmarks) {
        return;
    }

    const face = results.multiFaceLandmarks[0];

    const nose = face[1];

    const x = nose.x;
    const y = nose.y;

    if (previousNoseX !== 0) {

        if (Math.abs(x - previousNoseX) > 0.08) {

            headWarnings++;

            showWarning("Please keep looking at the screen.");

        }

    }

    previousNoseX = x;
    previousNoseY = y;

}