// ======================================================
// SmartHire AI - Interview Questions
// questions_v2.js
// ======================================================

const API = "http://127.0.0.1:8000";

// ------------------------------------------------------
// Interview state
// ------------------------------------------------------

let questions = [];
let currentQuestion = 0;
let interviewId = null;

window.followUpAsked = false;

let questionsLoading = false;
let reportGenerating = false;

// ------------------------------------------------------
// Answers
// ------------------------------------------------------

// Safely load interview answers
function loadStoredAnswers() {

    try {

        const saved =
            localStorage.getItem(
                "interviewAnswers"
            );

        if (!saved) {
            return [];
        }

        const parsed =
            JSON.parse(saved);

        return Array.isArray(parsed)
            ? parsed
            : [];

    }
    catch (error) {

        console.error(
            "❌ Invalid interviewAnswers in localStorage:",
            error
        );

        return [];
    }
}

window.interviewAnswers =
    loadStoredAnswers();


// ------------------------------------------------------
// Current question tracking
// ------------------------------------------------------

let currentMainQuestion = "";
let currentDisplayedQuestion = "";


// ======================================================
// RESUME DATA
// ======================================================

function getResumeData() {

    try {

        const saved =
            localStorage.getItem(
                "resumeData"
            );

        if (!saved) {
            return {};
        }

        const parsed =
            JSON.parse(saved);

        if (
            parsed &&
            typeof parsed === "object"
        ) {

            return parsed;
        }

        return {};

    }
    catch (error) {

        console.error(
            "❌ Invalid resumeData in localStorage:",
            error
        );

        return {};
    }
}


// ======================================================
// START INTERVIEW
// ======================================================

async function startInterview() {

    console.log("================================");
    console.log("🚀 STARTING INTERVIEW");
    console.log("================================");

    try {

        const userId =
            localStorage.getItem(
                "userId"
            );

        console.log(
            "👤 User ID:",
            userId
        );

        if (!userId) {

            throw new Error(
                "User ID not found. Please login again."
            );
        }

        const numericUserId =
            parseInt(
                userId,
                10
            );

        if (
            Number.isNaN(
                numericUserId
            )
        ) {

            throw new Error(
                "Invalid User ID."
            );
        }


        // --------------------------------------------------
        // START INTERVIEW API
        // --------------------------------------------------

        const response =
            await fetch(
                API + "/start_interview",
                {
                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/json"
                    },

                    body: JSON.stringify({

                        user_id:
                            numericUserId,

                        resume_filename:
                            localStorage.getItem(
                                "resume_filename"
                            ) ||
                            "resume.pdf"
                    })
                }
            );


        // --------------------------------------------------
        // Safely read backend response
        // --------------------------------------------------

        let data = {};

        try {

            data =
                await response.json();

        }
        catch (jsonError) {

            throw new Error(
                "Backend returned an invalid response while starting the interview."
            );
        }


        console.log(
            "🎯 Start Interview Response:",
            data
        );


        if (!response.ok) {

            throw new Error(
                data.detail ||
                "Failed to start interview."
            );
        }


        if (
            data.interview_id ===
            undefined ||
            data.interview_id ===
            null
        ) {

            throw new Error(
                "Backend did not return interview_id."
            );
        }


        // --------------------------------------------------
        // Save interview ID
        // --------------------------------------------------

        interviewId =
            String(
                data.interview_id
            );

        localStorage.setItem(
            "interviewId",
            interviewId
        );


        // --------------------------------------------------
        // New interview = new answers
        // --------------------------------------------------

        window.interviewAnswers =
            [];

        localStorage.setItem(
            "interviewAnswers",
            JSON.stringify(
                window.interviewAnswers
            )
        );


        console.log(
            "💾 Interview ID saved:",
            interviewId
        );

        console.log(
            "🧹 Previous interview answers cleared."
        );


        return true;
    }


    catch (error) {

        console.error(
            "❌ Start Interview Error:",
            error
        );


        alert(
            "Unable to start interview.\n\n" +
            error.message
        );


        return false;
    }
}


// ======================================================
// LOAD QUESTIONS
// ======================================================

async function loadQuestions() {

    // --------------------------------------------------
    // Prevent duplicate generation
    // --------------------------------------------------

    if (questionsLoading) {

        console.log(
            "⚠️ Questions are already loading."
        );

        return;
    }


    // --------------------------------------------------
    // If questions already exist, don't regenerate
    // --------------------------------------------------

    if (
        Array.isArray(
            questions
        ) &&
        questions.length > 0
    ) {

        console.log(
            "⚠️ Questions already exist. Skipping generation."
        );

        return;
    }


    questionsLoading =
        true;


    console.log("================================");
    console.log(
        "📚 LOADING INTERVIEW QUESTIONS"
    );
    console.log("================================");


    try {

        // --------------------------------------------------
        // Get interview ID
        // --------------------------------------------------

        let savedInterviewId =
            localStorage.getItem(
                "interviewId"
            );


        console.log(
            "Existing Interview ID:",
            savedInterviewId
        );


        // --------------------------------------------------
        // Create interview if needed
        // --------------------------------------------------

        if (!savedInterviewId) {

            console.log(
                "⚠️ No Interview ID found."
            );

            console.log(
                "🚀 Creating new interview..."
            );


            const started =
                await startInterview();


            if (!started) {

                throw new Error(
                    "Interview could not be started."
                );
            }


            savedInterviewId =
                localStorage.getItem(
                    "interviewId"
                );
        }


        if (!savedInterviewId) {

            throw new Error(
                "Interview ID could not be created."
            );
        }


        interviewId =
            String(
                savedInterviewId
            );


        console.log(
            "🆔 Current Interview ID:",
            interviewId
        );


        // --------------------------------------------------
        // Resume
        // --------------------------------------------------

        const resumeData =
            getResumeData();


        console.log(
            "📄 Resume data available:",
            Object.keys(
                resumeData
            ).length > 0
        );


        // --------------------------------------------------
        // Generate questions
        // --------------------------------------------------

        console.log(
            "🤖 Calling /generate_questions..."
        );


        const response =
            await fetch(
                API + "/generate_questions",
                {
                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/json"
                    },

                    body: JSON.stringify({

                        resume:
                            resumeData
                    })
                }
            );


        // --------------------------------------------------
        // Safely read backend response
        // --------------------------------------------------

        let data = {};

        try {

            data =
                await response.json();

        }
        catch (jsonError) {

            throw new Error(
                "Backend returned an invalid response while generating questions."
            );
        }


        console.log(
            "📥 Backend response:",
            data
        );


        if (!response.ok) {

            throw new Error(
                data.detail ||
                "Failed to generate questions."
            );
        }


        // --------------------------------------------------
        // Get questions
        // --------------------------------------------------

        questions =
            Array.isArray(
                data.questions
            )
                ? data.questions
                    .map(
                        question =>
                            String(
                                question ||
                                ""
                            ).trim()
                    )
                    .filter(
                        question =>
                            question.length > 0
                    )
                : [];


        console.log(
            "✅ Questions received:",
            questions.length
        );


        if (
            questions.length === 0
        ) {

            throw new Error(
                "Backend returned zero questions."
            );
        }


        // --------------------------------------------------
        // Reset interview question state
        // --------------------------------------------------

        currentQuestion =
            0;

        window.followUpAsked =
            false;

        window.currentFollowupQuestion =
            "";

        currentMainQuestion =
            questions[0];

        currentDisplayedQuestion =
            questions[0];


        // --------------------------------------------------
        // Load saved answers
        // --------------------------------------------------

        window.interviewAnswers =
            loadStoredAnswers();


        console.log(
            "📝 Stored answers loaded:",
            window.interviewAnswers.length
        );


        // --------------------------------------------------
        // Show first question
        // --------------------------------------------------

        await showQuestion();
    }


    catch (error) {

        console.error(
            "❌ Question Loading Error:",
            error
        );


        const status =
            document.getElementById(
                "status"
            );


        if (status) {

            status.innerHTML =
                "❌ Unable to load interview questions.";
        }


        alert(
            "Unable to load interview questions.\n\n" +
            error.message
        );
    }


    finally {

        questionsLoading =
            false;
    }
}


// ======================================================
// SHOW CURRENT QUESTION
// ======================================================

async function showQuestion() {

    // --------------------------------------------------
    // Validate questions
    // --------------------------------------------------

    if (
        !Array.isArray(
            questions
        ) ||
        questions.length === 0
    ) {

        console.error(
            "❌ No questions available."
        );

        return;
    }


    // --------------------------------------------------
    // Validate question index
    // --------------------------------------------------

    if (
        currentQuestion < 0 ||
        currentQuestion >=
        questions.length
    ) {

        console.error(
            "❌ Invalid question index:",
            currentQuestion
        );

        return;
    }


    // --------------------------------------------------
    // Get current question
    // --------------------------------------------------

    const question =
        String(
            questions[
                currentQuestion
            ] ||
            ""
        ).trim();


    if (!question) {

        console.error(
            "❌ Current question is empty."
        );

        return;
    }


    // --------------------------------------------------
    // Save current question globally
    // --------------------------------------------------

    window.currentQuestion =
        question;

    window.currentQuestionText =
        question;

    window.currentDisplayedQuestion =
        question;

    window.currentQuestionIndex =
        currentQuestion;

    window.currentFollowupQuestion =
        window.currentFollowupQuestion ||
        "";


    // Local state
    currentDisplayedQuestion =
        question;


    console.log(
        "🔥 SAVED CURRENT QUESTION:",
        question
    );


    console.log(
        "🔥 QUESTION INDEX:",
        currentQuestion + 1
    );


    console.log(
        "================================"
    );


    console.log(
        "❓ Current Question:",
        currentQuestion + 1,
        "/",
        questions.length
    );


    console.log(
        question
    );


    // --------------------------------------------------
    // Display question
    // --------------------------------------------------

    const questionElement =
        document.getElementById(
            "question"
        );


    if (questionElement) {

        questionElement.textContent =
            question;
    }


    // --------------------------------------------------
    // Status
    // --------------------------------------------------

    const statusElement =
        document.getElementById(
            "status"
        );


    if (statusElement) {

        statusElement.innerHTML =
            "Question " +
            (
                currentQuestion +
                1
            ) +
            " of " +
            questions.length;
    }


    // --------------------------------------------------
    // Speak question
    // --------------------------------------------------

    if (
        typeof window.speakQuestion ===
        "function"
    ) {

        try {

            await window.speakQuestion(
                question
            );

        }
        catch (speechError) {

            console.error(
                "⚠️ Speech error:",
                speechError
            );

            // Do NOT stop interview
        }
    }

    else {

        console.warn(
            "⚠️ speakQuestion() not available. Continuing without speech."
        );
    }
}


// ======================================================
// SAVE ANSWER
// ======================================================

function saveAnswerToMemory(
    questionText,
    answerText
) {

    const cleanQuestion =
        String(
            questionText ||
            ""
        ).trim();


    const cleanAnswer =
        String(
            answerText ||
            ""
        ).trim();


    // --------------------------------------------------
    // Ignore empty answer
    // --------------------------------------------------

    if (
        !cleanQuestion ||
        !cleanAnswer
    ) {

        console.log(
            "⚠️ Empty question/answer. Nothing saved."
        );

        return;
    }


    // --------------------------------------------------
    // Make sure answers array exists
    // --------------------------------------------------

    if (
        !Array.isArray(
            window.interviewAnswers
        )
    ) {

        window.interviewAnswers =
            [];
    }


    // --------------------------------------------------
    // Prevent exact duplicate
    // --------------------------------------------------

    const alreadySaved =
        window.interviewAnswers.some(
            item =>

                item &&
                item.question ===
                    cleanQuestion &&

                item.answer ===
                    cleanAnswer
        );


    if (alreadySaved) {

        console.log(
            "⚠️ Duplicate answer prevented."
        );

        return;
    }


    // --------------------------------------------------
    // Save answer
    // --------------------------------------------------

    const answerObject = {

        question:
            cleanQuestion,

        answer:
            cleanAnswer
    };


    window.interviewAnswers.push(
        answerObject
    );


    // --------------------------------------------------
    // Save to localStorage
    // --------------------------------------------------

    try {

        localStorage.setItem(
            "interviewAnswers",
            JSON.stringify(
                window.interviewAnswers
            )
        );

    }
    catch (storageError) {

        console.error(
            "❌ Could not save interview answers to localStorage:",
            storageError
        );
    }


    console.log(
        "💾 Interview answers stored in localStorage:",
        window.interviewAnswers.length
    );


    console.log(
        "💾 Answer saved:",
        answerObject
    );
}


// ======================================================
// NEXT QUESTION
// ======================================================

async function nextQuestion() {

    console.log("================================");
    console.log(
        "➡️ NEXT QUESTION"
    );
    console.log("================================");


    // --------------------------------------------------
    // Move to next main question
    // --------------------------------------------------

    currentQuestion++;


    window.followUpAsked =
        false;


    // --------------------------------------------------
    // Interview completed
    // --------------------------------------------------

    if (
        currentQuestion >=
        questions.length
    ) {

        console.log(
            "🎉 INTERVIEW COMPLETED"
        );


        const questionElement =
            document.getElementById(
                "question"
            );


        const statusElement =
            document.getElementById(
                "status"
            );


        if (questionElement) {

            questionElement.textContent =
                "🎉 Interview Completed";
        }


        if (statusElement) {

            statusElement.innerHTML =
                "🤖 Generating AI Report...";
        }


        // --------------------------------------------------
        // Generate final report
        // --------------------------------------------------

        await generateFinalReport();


        return;
    }


    // --------------------------------------------------
    // New main question
    // --------------------------------------------------

    currentMainQuestion =
        questions[
            currentQuestion
        ];


    window.currentFollowupQuestion =
        "";


    currentDisplayedQuestion =
        currentMainQuestion;


    // --------------------------------------------------
    // Clear transcript
    // --------------------------------------------------

    const transcript =
        document.getElementById(
            "transcript"
        );


    if (transcript) {

        transcript.value =
            "";
    }


    // --------------------------------------------------
    // Show new question
    // --------------------------------------------------

    await showQuestion();
}


// ======================================================
// GENERATE FINAL REPORT
// ======================================================

// ======================================================
// GENERATE FINAL REPORT
// ======================================================

async function generateFinalReport() {

    // --------------------------------------------------
    // Prevent duplicate report generation
    // --------------------------------------------------

    if (reportGenerating) {

        console.log(
            "⚠️ Report generation already running."
        );

        return;
    }

    reportGenerating = true;

    console.log("================================");
    console.log(
        "📊 GENERATING FINAL REPORT"
    );
    console.log("================================");

    try {

        // --------------------------------------------------
        // Get Interview ID
        // --------------------------------------------------

        const savedInterviewId =
            localStorage.getItem(
                "interviewId"
            );

        console.log(
            "🆔 Saved Interview ID:",
            savedInterviewId
        );

        if (!savedInterviewId) {

            throw new Error(
                "Interview ID not found."
            );
        }

        const numericInterviewId =
            parseInt(
                savedInterviewId,
                10
            );

        if (
            Number.isNaN(
                numericInterviewId
            )
        ) {

            throw new Error(
                "Invalid Interview ID."
            );
        }

        // --------------------------------------------------
        // IMPORTANT
        // --------------------------------------------------
        // We DO NOT check window.interviewAnswers here.
        //
        // Backend will get all answers directly from
        // PostgreSQL using the interview_id.
        // --------------------------------------------------

        console.log(
            "📤 Requesting final report from backend..."
        );

        console.log(
            "🆔 Interview ID:",
            numericInterviewId
        );

        // --------------------------------------------------
        // Call backend
        // --------------------------------------------------

        const response =
            await fetch(
                API +
                "/evaluate_interview",
                {
                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/json"
                    },

                    body:
                        JSON.stringify({

                            interview_id:
                                numericInterviewId

                        })
                }
            );

        // --------------------------------------------------
        // Read response
        // --------------------------------------------------

        let report = {};

        try {

            report =
                await response.json();

        }
        catch (jsonError) {

            throw new Error(
                "Backend returned an invalid response while generating the AI report."
            );
        }

        console.log(
            "📥 Backend Report:",
            report
        );

        // --------------------------------------------------
        // Check backend response
        // --------------------------------------------------

        if (!response.ok) {

            throw new Error(
                report.detail ||
                report.message ||
                "Failed to generate report."
            );
        }

        // --------------------------------------------------
        // Save report locally
        // --------------------------------------------------

        try {

            localStorage.setItem(
                "interviewReport",
                JSON.stringify(
                    report
                )
            );

        }
        catch (storageError) {

            console.error(
                "⚠️ Could not save report to localStorage:",
                storageError
            );
        }

        // --------------------------------------------------
        // Display final report
        // --------------------------------------------------

        displayFinalReport(
            report
        );

        console.log(
            "✅ FINAL REPORT GENERATED SUCCESSFULLY"
        );

    }

    catch (error) {

        console.error(
            "❌ FINAL REPORT ERROR:",
            error
        );

        const statusElement =
            document.getElementById(
                "status"
            );

        if (statusElement) {

            statusElement.innerHTML =
                "❌ Failed to generate AI report.";
        }

        alert(
            "Failed to generate interview report.\n\n" +
            error.message
        );
    }

    finally {

        reportGenerating =
            false;
    }
}

// ======================================================
// DISPLAY FINAL REPORT
// ======================================================

function displayFinalReport(
    report
) {

    console.log(
        "📋 DISPLAYING FINAL REPORT"
    );


    // --------------------------------------------------
    // Safety check
    // --------------------------------------------------

    if (
        !report ||
        typeof report !==
        "object"
    ) {

        console.error(
            "❌ Invalid report received:",
            report
        );

        return;
    }


    const questionElement =
        document.getElementById(
            "question"
        );


    const statusElement =
        document.getElementById(
            "status"
        );


    // --------------------------------------------------
    // Header
    // --------------------------------------------------

    if (questionElement) {

        questionElement.textContent =
            "📋 SmartHire AI Interview Report";
    }


    // --------------------------------------------------
    // Status element
    // --------------------------------------------------

    if (!statusElement) {

        console.error(
            "❌ status element not found."
        );

        return;
    }


    // --------------------------------------------------
    // Strengths
    // --------------------------------------------------

    const strengths =
        Array.isArray(
            report.strengths
        )
            ? report.strengths
            : [];


    // --------------------------------------------------
    // Improvements
    // --------------------------------------------------

    const improvements =
        Array.isArray(
            report.improvements
        )
            ? report.improvements
            : [];


    // --------------------------------------------------
    // Safe helper for report values
    // --------------------------------------------------

    const safeValue =
        value => {

            if (
                value ===
                undefined ||
                value ===
                null ||
                value ===
                ""
            ) {

                return 0;
            }

            return value;
        };


    // --------------------------------------------------
    // Display report
    // --------------------------------------------------

    statusElement.innerHTML = `

        <div class="report-container">

            <h3>📊 Interview Results</h3>

            <hr>

            <b>Overall Score:</b>
            ${safeValue(report.overall_score)}/100

            <br><br>

            <b>Communication:</b>
            ${safeValue(report.communication)}/10

            <br>

            <b>Technical:</b>
            ${safeValue(report.technical)}/10

            <br>

            <b>Confidence:</b>
            ${safeValue(report.confidence)}/10

            <br>

            <b>HR Skills:</b>
            ${safeValue(report.hr_skills)}/10

            <br>

            <b>Behavioral:</b>
            ${safeValue(report.behavioral)}/10

            <br>

            <b>Problem Solving:</b>
            ${safeValue(report.problem_solving)}/10

            <br><br>

            <h4>💪 Strengths</h4>

            ${
                strengths.length > 0
                    ? strengths
                        .map(
                            item =>
                                `<div>• ${item}</div>`
                        )
                        .join("")
                    : "No strengths available"
            }

            <br>

            <h4>📈 Areas to Improve</h4>

            ${
                improvements.length > 0
                    ? improvements
                        .map(
                            item =>
                                `<div>• ${item}</div>`
                        )
                        .join("")
                    : "No improvement areas available"
            }

            <br>

            <h4>🎯 Recommendation</h4>

            ${
                report.recommendation ||
                "No recommendation available"
            }

        </div>
    `;


    console.log(
        "✅ FINAL REPORT DISPLAYED"
    );
}


// ======================================================
// GLOBAL FUNCTIONS
// ======================================================

window.startInterview =
    startInterview;


window.loadQuestions =
    loadQuestions;


window.nextQuestion =
    nextQuestion;


window.generateFinalReport =
    generateFinalReport;


window.saveAnswerToMemory =
    saveAnswerToMemory;


// ======================================================
// COMPATIBILITY FOR speech_v2.js
// ======================================================

window.saveResponse =
    saveAnswerToMemory;


console.log(
    "✅ saveResponse compatibility function available:",
    typeof window.saveResponse ===
        "function"
);


// ======================================================
// DOM READY
//
// IMPORTANT:
// DO NOT call loadQuestions() here.
//
// interview_v2.html is the ONLY place
// that starts the interview.
// ======================================================

window.addEventListener(
    "DOMContentLoaded",
    function () {

        console.log(
            "================================"
        );


        console.log(
            "🤖 SmartHire AI Interview Page"
        );


        console.log(
            "================================"
        );


        console.log(
            "User ID:",
            localStorage.getItem(
                "userId"
            )
        );


        console.log(
            "Interview ID:",
            localStorage.getItem(
                "interviewId"
            )
        );


        console.log(
            "📝 Stored answers:",
            window.interviewAnswers.length
        );


        console.log(
            "📌 Waiting for interview_v2.html to start questions..."
        );
    }
);