// ============================================================
// SmartHire AI - Proctoring
// ============================================================

console.log("================================");
console.log("🛡️ SmartHire AI Proctoring");
console.log("================================");

let cameraStream = null;
let proctoringStarted = false;


// ============================================================
// GET CAMERA ELEMENTS
// ============================================================

function getProctorElements() {

    const video =
        document.getElementById("camera");

    const canvas =
        document.getElementById("canvas");

    const proctorCanvas =
        document.getElementById("proctorCanvas");

    console.log(
        "📷 Camera element:",
        video
    );

    console.log(
        "🎨 Processing canvas:",
        canvas
    );

    console.log(
        "🎨 Proctor canvas:",
        proctorCanvas
    );

    return {
        video,
        canvas,
        proctorCanvas
    };
}


// ============================================================
// START CAMERA
// ============================================================

async function startCamera() {

    console.log("📷 Starting camera...");

    const {
        video,
        canvas,
        proctorCanvas
    } = getProctorElements();


    if (!video) {

        console.error(
            "❌ Proctoring: #camera element not found."
        );

        return false;
    }


    if (!canvas) {

        console.error(
            "❌ Proctoring: #canvas element not found."
        );

        return false;
    }


    if (!proctorCanvas) {

        console.error(
            "❌ Proctoring: #proctorCanvas element not found."
        );

        return false;
    }


    try {

        cameraStream =
            await navigator.mediaDevices.getUserMedia({
                video: true,
                audio: false
            });


        video.srcObject =
            cameraStream;


        await video.play();


        console.log(
            "✅ Camera started successfully."
        );


        console.log(
            "📷 Camera tracks:",
            cameraStream.getVideoTracks()
        );


        return true;

    } catch (error) {

        console.error(
            "❌ Camera access failed:",
            error
        );


        console.error(
            "Error name:",
            error.name
        );


        console.error(
            "Error message:",
            error.message
        );


        return false;
    }
}


// ============================================================
// STOP CAMERA
// ============================================================

function stopCamera() {

    console.log(
        "🛑 Stopping camera..."
    );


    if (cameraStream) {

        cameraStream
            .getTracks()
            .forEach(track => {

                track.stop();

            });


        cameraStream = null;

    }


    const video =
        document.getElementById("camera");


    if (video) {

        video.srcObject = null;

    }


    console.log(
        "✅ Camera stopped."
    );
}


// ============================================================
// START PROCTORING
// ============================================================

async function startProctoring() {

    if (proctoringStarted) {

        console.log(
            "⚠️ Proctoring already started."
        );

        return;

    }


    console.log(
        "🛡️ Starting SmartHire AI proctoring..."
    );


    const success =
        await startCamera();


    if (!success) {

        console.error(
            "❌ Proctoring could not start."
        );

        return;

    }


    proctoringStarted = true;


    console.log(
        "✅ SmartHire AI Proctoring started."
    );


    // --------------------------------------------------------
    // Basic camera frame processing
    // --------------------------------------------------------

    startCameraProcessing();
}


// ============================================================
// BASIC CAMERA PROCESSING
// ============================================================

function startCameraProcessing() {

    const video =
        document.getElementById("camera");

    const canvas =
        document.getElementById("canvas");

    const proctorCanvas =
        document.getElementById("proctorCanvas");


    if (
        !video ||
        !canvas ||
        !proctorCanvas
    ) {

        console.error(
            "❌ Camera processing elements missing."
        );

        return;

    }


    const ctx =
        canvas.getContext("2d");


    const overlayCtx =
        proctorCanvas.getContext("2d");


    function processFrame() {

        if (
            !video ||
            video.readyState < 2
        ) {

            requestAnimationFrame(
                processFrame
            );

            return;

        }


        // ----------------------------------------------------
        // Draw current camera frame to hidden canvas
        // ----------------------------------------------------

        ctx.drawImage(
            video,
            0,
            0,
            canvas.width,
            canvas.height
        );


        // ----------------------------------------------------
        // Clear overlay
        // ----------------------------------------------------

        overlayCtx.clearRect(
            0,
            0,
            proctorCanvas.width,
            proctorCanvas.height
        );


        // ----------------------------------------------------
        // Simple camera-active border
        // ----------------------------------------------------

        overlayCtx.strokeStyle =
            "#00ff00";

        overlayCtx.lineWidth =
            3;

        overlayCtx.strokeRect(
            1,
            1,
            proctorCanvas.width - 2,
            proctorCanvas.height - 2
        );


        requestAnimationFrame(
            processFrame
        );

    }


    processFrame();


    console.log(
        "✅ Camera frame processing started."
    );
}


// ============================================================
// EXPOSE FUNCTIONS GLOBALLY
// ============================================================

window.startCamera =
    startCamera;

window.stopCamera =
    stopCamera;

window.startProctoring =
    startProctoring;


// ============================================================
// DO NOT AUTO-START HERE
// ============================================================

console.log(
    "✅ proctor.js loaded."
);

console.log(
    "👉 Waiting for interview_v2.js to call startProctoring()."
);