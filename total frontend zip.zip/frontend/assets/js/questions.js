const API = "http://127.0.0.1:8000";

let questions = [];
let currentQuestion = 0;

async function loadQuestions() {
    console.log("loadQuestions called");
    alert("loadQuestions Started");

    try {

        const response = await fetch(API + "/interview_questions");

        alert("Response Received");

        const data = await response.json();

        alert("JSON Received");

        questions = data.questions;

        document.getElementById("question").innerHTML =
            questions[currentQuestion];

        alert("Question Displayed");

        speakQuestion(questions[currentQuestion]);

    }
    catch(err){

        alert("ERROR : " + err);

    }

}

function nextQuestion() {

    currentQuestion++;

    if(currentQuestion >= questions.length){

        document.getElementById("question").innerHTML =
        "Interview Completed";

        return;

    }

    document.getElementById("question").innerHTML =
    questions[currentQuestion];

    speakQuestion(questions[currentQuestion]);

}