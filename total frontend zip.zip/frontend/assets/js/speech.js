alert("Speech.js Loaded");

window.addEventListener("load", function () {

    alert("Page Loaded");

    const startBtn = document.getElementById("startBtn");

    if (!startBtn) {
        alert("Start Button NOT Found");
        return;
    }

    alert("Start Button Found");
let mediaRecorder;
let audioChunks = [];

startBtn.onclick = async function () {

    const stream = await navigator.mediaDevices.getUserMedia({
        audio: true
    });

    mediaRecorder = new MediaRecorder(stream);

    audioChunks = [];

    mediaRecorder.ondataavailable = function(event) {
        audioChunks.push(event.data);
    };

    mediaRecorder.start();

    alert("🎙 Recording Started");
    document.getElementById("stopBtn").onclick = function () {

    mediaRecorder.stop();

    mediaRecorder.onstop = async function () {

        alert("Uploading Audio...");

        const audioBlob = new Blob(audioChunks, {
            type: "audio/webm"
        });

        const formData = new FormData();

        formData.append(
            "audio",
            audioBlob,
            "answer.webm"
        );

        try {

            const response = await fetch("http://127.0.0.1:8000/transcribe", {
                method: "POST",
                body: formData
            });

            const result = await response.json();

            document.getElementById("output").value =
                result.transcript;

            alert("✅ Transcript Received");
            setTimeout(function () {

    nextQuestion();

}, 2000);

        } catch (err) {

            alert("Error: " + err);

        }

    };

};

};
    

});