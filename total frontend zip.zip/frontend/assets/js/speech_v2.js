// ======================================================
// SmartHire AI - Speech V2
// ======================================================

console.log("================================");
console.log("🎤 SmartHire AI Speech V2 Loaded");
console.log("================================");

(function () {

    // ==================================================
    // STATE
    // ==================================================

    let mediaRecorder = null;
    let mediaStream = null;
    let audioChunks = [];
    let speechTimer = null;

    // IMPORTANT:
    // Keep this state inside one object.
    // This prevents duplicate "followUpAsked" declaration errors.
    const speechState = {
        processing: false,
        followUpAsked: false,
        currentQuestion: "",
        currentAnswer: "",
        currentAudioFile: ""
    };


    // ==================================================
    // HELPER: GET ELEMENT
    // ==================================================

    function getElement(id) {
        return document.getElementById(id);
    }


    // ==================================================
    // HELPER: STATUS
    // ==================================================

    function setStatus(message) {

        const status = getElement("status");

        if (status) {
            status.innerHTML = message;
        }
    }


    // ==================================================
    // HELPER: MICROPHONE UI
    // ==================================================

    function showMic(show) {

        const micAnimation = getElement("micAnimation");

        if (micAnimation) {
            micAnimation.style.display =
                show ? "block" : "none";
        }
    }


    // ==================================================
    // HELPER: TRANSCRIPT
    // ==================================================

    function displayTranscript(text) {

        const transcript = getElement("transcript");

        if (!transcript) {
            console.error(
                "❌ #transcript element not found."
            );
            return;
        }

        transcript.value = text || "";

        console.log(
            "📝 Transcript displayed:",
            text
        );
    }


    // ==================================================
    // HELPER: CURRENT QUESTION
    // ==================================================

    function getCurrentQuestion() {

        // First preference
        if (
            typeof window.currentDisplayedQuestion ===
            "string" &&
            window.currentDisplayedQuestion.trim()
        ) {
            return window.currentDisplayedQuestion;
        }

        // Second preference
        if (
            typeof window.currentQuestion ===
            "string" &&
            window.currentQuestion.trim()
        ) {
            return window.currentQuestion;
        }

        // Third preference
        const questionElement =
            getElement("question");

        if (questionElement) {

            const text =
                questionElement.textContent.trim();

            if (
                text &&
                text !== "Loading Question..."
            ) {
                return text;
            }
        }

        return "";
    }


    // ==================================================
    // HELPER: SAFE JSON FETCH
    // ==================================================

    async function fetchJSON(url, options = {}) {

        const response =
            await fetch(url, options);

        const contentType =
            response.headers.get(
                "content-type"
            ) || "";

        const rawText =
            await response.text();

        console.log(
            "🌐 HTTP:",
            response.status,
            "| Content-Type:",
            contentType
        );

        console.log(
            "📥 Raw response:",
            rawText
        );

        if (!response.ok) {

            throw new Error(
                `${response.status}: ${rawText}`
            );
        }

        if (
            !contentType.includes(
                "application/json"
            )
        ) {

            throw new Error(
                "Backend did not return JSON: " +
                rawText
            );
        }

        return JSON.parse(rawText);
    }

    // ==================================================
// START LISTENING
// ==================================================

async function startListening() {

    console.log("================================");
    console.log("🎤 START LISTENING");
    console.log("================================");


    // ==================================================
    // 1. PREVENT DUPLICATE PROCESSING
    // ==================================================

    if (speechState.processing) {

        console.log(
            "⚠️ Speech processing already running."
        );

        return;
    }


    // ==================================================
    // 2. PREVENT DUPLICATE RECORDING
    // ==================================================

    if (
        mediaRecorder &&
        mediaRecorder.state === "recording"
    ) {

        console.log(
            "⚠️ Recorder is already recording."
        );

        return;
    }


    // ==================================================
    // 3. RESET STATE
    // ==================================================

    speechState.processing = false;
    speechState.recording = false;

    audioChunks = [];


    // ==================================================
    // 4. UPDATE UI
    // ==================================================

    setStatus(
        "🎤 Listening... Speak your answer."
    );

    showMic(true);


    try {

        // ==============================================
        // 5. GET MICROPHONE
        // ==============================================

        mediaStream =
            await navigator.mediaDevices.getUserMedia({
                audio: true
            });

        console.log(
            "🎤 Microphone permission granted."
        );


        // ==============================================
        // 6. CHECK BROWSER MEDIARECORDER
        // ==============================================

        if (
            typeof MediaRecorder ===
            "undefined"
        ) {

            throw new Error(
                "MediaRecorder is not supported by this browser."
            );
        }


        // ==============================================
        // 7. FIND SUPPORTED AUDIO FORMAT
        // ==============================================

        let mimeType = "";


        if (
            MediaRecorder.isTypeSupported(
                "audio/webm;codecs=opus"
            )
        ) {

            mimeType =
                "audio/webm;codecs=opus";

        }

        else if (
            MediaRecorder.isTypeSupported(
                "audio/webm"
            )
        ) {

            mimeType =
                "audio/webm";

        }

        else if (
            MediaRecorder.isTypeSupported(
                "audio/ogg;codecs=opus"
            )
        ) {

            mimeType =
                "audio/ogg;codecs=opus";
        }


        console.log(
            "🎵 Selected MIME:",
            mimeType ||
            "browser default"
        );


        // ==============================================
        // 8. CREATE MEDIA RECORDER
        // ==============================================

        if (mimeType) {

            mediaRecorder =
                new MediaRecorder(
                    mediaStream,
                    {
                        mimeType:
                            mimeType
                    }
                );

        }

        else {

            mediaRecorder =
                new MediaRecorder(
                    mediaStream
                );
        }


        console.log(
            "🎵 Recording MIME:",
            mediaRecorder.mimeType
        );


        // ==============================================
        // 9. RECEIVE AUDIO CHUNKS
        // ==============================================

        mediaRecorder.ondataavailable =
            function (event) {

                if (
                    event.data &&
                    event.data.size > 0
                ) {

                    audioChunks.push(
                        event.data
                    );

                    console.log(
                        "📦 Audio chunk:",
                        event.data.size,
                        "bytes"
                    );
                }
            };


        // ==============================================
        // 10. RECORDER ERROR
        // ==============================================

        mediaRecorder.onerror =
            function (event) {

                console.error(
                    "❌ MediaRecorder error:",
                    event
                );
            };


        // ==============================================
        // 11. RECORDER STOP
        // ==============================================

        mediaRecorder.onstop =
            async function () {

                console.log(
                    "🎤 Recording stopped."
                );


                clearTimeout(
                    speechTimer
                );


                speechState.recording =
                    false;


                // --------------------------------------
                // Stop microphone tracks
                // --------------------------------------

                if (mediaStream) {

                    mediaStream
                        .getTracks()
                        .forEach(
                            track =>
                                track.stop()
                        );

                    mediaStream =
                        null;
                }


                // --------------------------------------
                // Process answer
                // --------------------------------------

                await processRecordedAnswer();
            };


        // ==============================================
        // 12. START RECORDING
        // ==============================================

        mediaRecorder.start(250);

        speechState.recording =
            true;

        console.log(
            "🎤 Recording started."
        );


        // ==============================================
        // 13. 10 SECOND TIMER
        // ==============================================

        speechTimer =
            setTimeout(
                function () {

                    if (
                        mediaRecorder &&
                        mediaRecorder.state ===
                        "recording"
                    ) {

                        console.log(
                            "⏱️ 10 seconds completed."
                        );

                        mediaRecorder.stop();
                    }

                },
                10000
            );


    }

    catch (error) {

        console.error(
            "❌ Microphone Error:",
            error
        );

        speechState.processing =
            false;

        speechState.recording =
            false;


        clearTimeout(
            speechTimer
        );


        if (mediaStream) {

            mediaStream
                .getTracks()
                .forEach(
                    track =>
                        track.stop()
                );

            mediaStream =
                null;
        }


        mediaRecorder =
            null;


        showMic(false);


        setStatus(
            "❌ Microphone error: " +
            error.message
        );
    }
}


    // ======================================================
    // STOP LISTENING
    // ======================================================

    function stopListening() {

        clearTimeout(
            speechTimer
        );

        if (
            mediaRecorder &&
            mediaRecorder.state === "recording"
        ) {

            console.log(
                "🛑 Stopping recording..."
            );

            mediaRecorder.stop();

        } else {

            console.log(
                "⚠️ No active recording."
            );
        }
    }


    // ======================================================
    // PROCESS RECORDED ANSWER
    // ======================================================

    async function processRecordedAnswer() {

        if (speechState.processing) {

            console.log(
                "⚠️ Speech processing already running."
            );

            return;
        }


        speechState.processing = true;


        console.log(
            "================================"
        );

        console.log(
            "🔄 PROCESSING CANDIDATE ANSWER"
        );

        console.log(
            "================================"
        );


        setStatus(
            "🔄 Processing your answer..."
        );

        showMic(false);


        try {

            // ==========================================
            // GET CURRENT QUESTION
            // ==========================================

            const question =
                getCurrentQuestion();


            speechState.currentQuestion =
                question;


            console.log(
                "🔥 QUESTION FOR ANSWER:",
                question
            );


            if (!question) {

                throw new Error(
                    "Current question not found."
                );
            }


            // ==========================================
            // CHECK AUDIO
            // ==========================================

            console.log(
                "📦 Audio chunks:",
                audioChunks.length
            );


            if (
                !audioChunks ||
                audioChunks.length === 0
            ) {

                throw new Error(
                    "No audio was recorded."
                );
            }


            // ==========================================
            // CREATE AUDIO BLOB
            // ==========================================

            let audioType =
                "audio/webm";


            if (
                mediaRecorder &&
                mediaRecorder.mimeType
            ) {

                audioType =
                    mediaRecorder.mimeType;
            }


            const audioBlob =
                new Blob(
                    audioChunks,
                    {
                        type: audioType
                    }
                );


            console.log(
                "🎵 Audio type:",
                audioType
            );

            console.log(
                "📦 Audio size:",
                audioBlob.size
            );


            if (
                audioBlob.size < 1000
            ) {

                throw new Error(
                    "Recorded audio is too small. Please answer again."
                );
            }


            // ==========================================
            // SEND AUDIO TO TRANSCRIBE
            // ==========================================

            const formData =
                new FormData();


            formData.append(
                "audio",
                audioBlob,
                "candidate_answer.webm"
            );


            console.log(
                "📤 Sending audio to /transcribe..."
            );


            const transcriptionResponse =
                await fetchJSON(
                    "http://127.0.0.1:8000/transcribe",
                    {
                        method: "POST",
                        body: formData
                    }
                );


            console.log(
                "📥 Transcription response:",
                transcriptionResponse
            );


            const transcript =
    (
        transcriptionResponse.transcript ||
        ""
    ).trim();

console.log("================================");
console.log("📝 TRANSCRIPTION DEBUG");
console.log("================================");

console.log(
    "📥 Full transcription response:",
    transcriptionResponse
);

console.log(
    "📝 Transcript:",
    transcript
);

console.log(
    "📏 Transcript length:",
    transcript.length
);

console.log(
    "🎵 Audio file returned:",
    transcriptionResponse.audio_file
);

console.log("================================");


            // ==========================================
            // DISPLAY TRANSCRIPT
            // ==========================================

            displayTranscript(
                transcript
            );


            // ==========================================
            // NO SPEECH
            // ==========================================

            if (!transcript) {

                setStatus(
                    "⚠️ No speech detected. Please answer again."
                );

                speechState.processing =
                    false;

                return;
            }


            // ==========================================
            // SAVE STATE
            // ==========================================

            speechState.currentAnswer =
                transcript;

            speechState.currentAudioFile =
    transcriptionResponse.audio_file || "";

window.lastCandidateAudioFile =
    transcriptionResponse.audio_file || null;


            // ==========================================
            // SAVE ANSWER TO DATABASE
            // ==========================================

            const userId =
                localStorage.getItem(
                    "userId"
                );

            const interviewId =
                localStorage.getItem(
                    "interviewId"
                );


            console.log(
                "💾 Saving answer..."
            );


            const savePayload = {

                user_id:
                    userId
                        ? Number(userId)
                        : null,

                interview_id:
                    interviewId
                        ? Number(interviewId)
                        : null,

                question:
                    question,

                answer:
                    transcript,

                audio_file:
                    transcriptionResponse.audio_file ||
                    null
            };


            console.log(
                "💾 Save payload:",
                savePayload
            );


        const questionNumber =
    Number(window.currentQuestionIndex) + 1;

console.log("================================");
console.log("💾 SENDING ANSWER TO BACKEND");
console.log("================================");
console.log("Interview ID:", interviewId);
console.log("Question Index:", window.currentQuestionIndex);
console.log("Question Number:", questionNumber);
console.log("Question:", question);
console.log("Answer:", transcript);

const saveResponse = await fetch(
    "http://127.0.0.1:8000/save_answer",
    {
        method: "POST",

        headers: {
            "Content-Type": "application/json"
        },

        body: JSON.stringify({

            interview_id:
                Number(interviewId),

            question_number:
                questionNumber,

            question:
                question,

            answer:
                transcript,

            // AI question audio
            ai_audio_file:
                window.lastAIAudioFile || null,

            // Candidate recording
            candidate_audio_file:
                window.lastCandidateAudioFile || null
        })
    }
);   

            console.log(
    "📥 Save answer response:",
    saveResponse
);

if (!saveResponse.ok) {

    const errorText =
        await saveResponse.text();

    throw new Error(
        "Failed to save answer: " +
        errorText
    );
}

console.log(
    "✅ Answer saved to database."
);

            // ==========================================
            // FOLLOW-UP QUESTION
            // ==========================================

            console.log(
                "================================"
            );

            console.log(
                "🤖 FOLLOW-UP LOGIC"
            );

            console.log(
                "================================"
            );


            // One follow-up per main question
            if (
                !speechState.followUpAsked
            ) {

                speechState.followUpAsked =
                    true;


                console.log(
                    "🤖 Requesting follow-up..."
                );


                const followupResponse =
                    await fetchJSON(
                        "http://127.0.0.1:8000/followup_question",
                        {
                            method: "POST",

                            headers: {
                                "Content-Type":
                                    "application/json"
                            },

                            body:
                                JSON.stringify({

                                    question:
                                        question,

                                    answer:
                                        transcript
                                })
                        }
                    );


                console.log(
                    "📥 Follow-up response:",
                    followupResponse
                );


                const followup =
                    (
                        followupResponse.followup ||
                        ""
                    ).trim();


                if (followup) {

                    console.log(
                        "996 🤖 Follow-up:",
                        followup
                    );


                    // ==================================
                    // DISPLAY FOLLOW-UP
                    // ==================================

                    const questionElement =
                        getElement("question");


                    if (questionElement) {

                        questionElement.textContent =
                            followup;
                    }


                    setStatus(
                        "🤖 AI is asking a follow-up question..."
                    );

                // ==================================
// IMPORTANT
// Speak follow-up.
// voice_v2.js will automatically
// call startListening() after audio.
// ==================================

if (
    typeof window.speakQuestion ===
    "function"
) {

    // ----------------------------------
    // IMPORTANT:
    // Allow the next recording BEFORE
    // voice_v2.js calls startListening()
    // ----------------------------------

    speechState.processing = false;

    console.log(
        "✅ Speech processing unlocked."
    );

    await window.speakQuestion(
        followup
    );

} else {

    console.error(
        "❌ speakQuestion() is not available."
    );

    // ----------------------------------
    // Fallback
    // ----------------------------------

    speechState.processing = false;

    await startListening();
}


// ==================================
// RETURN
// ==================================

return;
                }
            }


            // ==========================================
            // MAIN QUESTION COMPLETED
            // ==========================================

            console.log(
                "✅ Answer completed."
            );


            // Reset follow-up state
            speechState.followUpAsked =
                false;


            // ==========================================
            // MOVE TO NEXT QUESTION
            // ==========================================

            if (
                typeof window.nextQuestion ===
                "function"
            ) {

                console.log(
                    "➡️ Moving to next question..."
                );

                window.nextQuestion();

            } else {

                console.warn(
                    "⚠️ nextQuestion() not available."
                );

                const nextButton =
                    getElement("nextBtn");

                if (nextButton) {
                    nextButton.style.display =
                        "block";
                }
            }


        } catch (error) {

            console.error(
                "❌ Audio Processing Error:",
                error
            );


            setStatus(
                "❌ " +
                error.message
            );


        } finally {

            audioChunks = [];

            speechState.processing =
                false;


            console.log(
                "================================"
            );

            console.log(
                "✅ Speech processing finished."
            );

            console.log(
                "================================"
            );
        }
    }
    console.log("🔍 BEFORE GLOBAL EXPORT");
    console.log("startListening local:", typeof startListening);
    console.log("stopListening local:", typeof stopListening);
    console.log("processRecordedAnswer local:", typeof processRecordedAnswer);


    // ======================================================
    // EXPORT EVERYTHING GLOBALLY
    // ======================================================

    window.startListening =
        startListening;

    window.stopListening =
        stopListening;

    window.processRecordedAnswer =
        processRecordedAnswer;


    // Useful for other JS files
    window.smartHireSpeechState =
        speechState;


    console.log(
        "================================"
    );

    console.log(
        "✅ speech_v2.js functions available globally."
    );

    console.log(
        "👉 startListening available:",
        typeof window.startListening ===
        "function"
    );

    console.log(
        "👉 stopListening available:",
        typeof window.stopListening ===
        "function"
    );

    console.log(
        "👉 processRecordedAnswer available:",
        typeof window.processRecordedAnswer ===
        "function"
    );

})();

