window.addEventListener("DOMcontentload", function () {
    alert("Interview.js Loaded");

    loadQuestions();
});