const API = "http://127.0.0.1:8000";

let mediaRecorder;
let audioChunks = [];
let stream;
let silenceTimer;
let analyser;
let audioContext;
let dataArray;
// -----------------------------------
// Start Microphone
// -----------------------------------
async function startListening() {

    document.getElementById("status").innerHTML =
        "🎤 Listening...";

    document.getElementById("micAnimation").style.display =
        "block";

    try {

        stream = await navigator.mediaDevices.getUserMedia({
            audio: true
        });

        console.log("✅ Microphone Permission Granted");

        audioChunks = [];

        mediaRecorder = new MediaRecorder(stream);

        mediaRecorder.ondataavailable = function (event) {

            if (event.data.size > 0) {

                audioChunks.push(event.data);

            }

        };

        mediaRecorder.onstart = function () {

            console.log("🎙 Recording Started");

        };

        mediaRecorder.start();

    }

    catch (err) {

        console.error(err);

        alert("Microphone Error : " + err.message);

    }

}
window.startListening = startListening;