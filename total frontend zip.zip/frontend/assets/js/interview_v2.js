
// ======================================================
// SmartHire AI - Interview Page Controller
// interview_v2.js
// ======================================================

window.addEventListener(
    "DOMContentLoaded",
    async function () {

        console.log("================================");
        console.log(
            "🤖 SmartHire AI Interview Controller"
        );
        console.log("================================");

        try {

            // --------------------------------------------------
            // Start proctoring
            // --------------------------------------------------

            if (
                typeof window.startProctoring ===
                "function"
            ) {

                console.log(
                    "🛡️ Starting proctoring..."
                );

                await window.startProctoring();

            }
            else {

                console.error(
                    "❌ startProctoring() is not available."
                );
            }

            // --------------------------------------------------
            // Start questions
            // --------------------------------------------------

            if (
                typeof window.loadQuestions ===
                "function"
            ) {

                console.log(
                    "📚 Loading interview questions..."
                );

                await window.loadQuestions();

                console.log(
                    "✅ Interview questions loaded."
                );
            }
            else {

                console.error(
                    "❌ loadQuestions() is not available."
                );
            }
        }

        catch (error) {

            console.error(
                "❌ Interview controller error:",
                error
            );

            const status =
                document.getElementById(
                    "status"
                );

            if (status) {

                status.innerHTML =
                    "❌ Unable to start interview.";
            }
        }
    }
);
