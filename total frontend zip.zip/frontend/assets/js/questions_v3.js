const API = "http://127.0.0.1:8000";

let questions = [];
let currentQuestion = 0;

// Store all interview answers
window.interviewAnswers = [];

// Load interview questions
async function loadQuestions() {

    try {

        const response = await fetch(API + "/interview_questions");

        const data = await response.json();

        questions = data.questions;

        showQuestion();

    }

    catch (err) {

        console.error(err);

        document.getElementById("status").innerHTML =
            "❌ Unable to load interview questions.";

    }

}

// Display current question
function showQuestion() {

    document.getElementById("question").innerHTML =
        questions[currentQuestion];

    speakQuestion(questions[currentQuestion]);

}

// Move to next question
function nextQuestion() {

    currentQuestion++;

    if (currentQuestion >= questions.length) {

        document.getElementById("question").innerHTML =
            "🎉 Interview Completed";

        document.getElementById("status").innerHTML =
            "Generating Final Report...";

        return;

    }

    showQuestion();

}