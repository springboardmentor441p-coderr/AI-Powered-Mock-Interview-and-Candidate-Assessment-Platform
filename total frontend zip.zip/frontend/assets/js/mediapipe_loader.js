async function loadMediaPipe(){

    const faceDetection=document.createElement("script");
    faceDetection.src="https://cdn.jsdelivr.net/npm/@mediapipe/face_detection/face_detection.js";

    document.head.appendChild(faceDetection);

    await new Promise(resolve=>{
        faceDetection.onload=resolve;
    });

    const camera=document.createElement("script");
    camera.src="https://cdn.jsdelivr.net/npm/@mediapipe/camera_utils/camera_utils.js";

    document.head.appendChild(camera);

    await new Promise(resolve=>{
        camera.onload=resolve;
    });

}