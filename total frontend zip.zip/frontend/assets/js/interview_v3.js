window.addEventListener("DOMContentLoaded", function () {

    loadQuestions();

});