function speakQuestion(question) {

    const speech = new SpeechSynthesisUtterance();

    speech.text = question;

    speech.lang = "en-US";

    speech.rate = 1;

    speech.pitch = 1;

    speech.volume = 1;

    window.speechSynthesis.speak(speech);
}