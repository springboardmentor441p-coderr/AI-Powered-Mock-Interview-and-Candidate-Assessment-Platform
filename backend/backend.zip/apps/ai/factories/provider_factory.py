"""
Provider factory: the only place that maps a configured provider name
(`settings.AI_SERVICE_PROVIDER`) to a concrete adapter class for each
AI capability. `core.container` calls into this factory rather than
importing adapters directly, so adding a third provider (e.g. Gemini
for question generation) means editing one branch here - no other
file changes.
"""
from apps.ai.providers.emotion.interfaces import IEmotionDetectionProvider
from apps.ai.providers.eye_tracking.interfaces import IEyeContactTrackingProvider
from apps.ai.providers.llm.interfaces import (
    IFeedbackGenerationProvider,
    IQuestionGenerationProvider,
    IResumeExtractionProvider,
)
from apps.ai.providers.realtime_voice.interfaces import IRealtimeVoiceProvider
from apps.ai.providers.speech.interfaces import ICommunicationAnalysisProvider, ISpeechToTextProvider


class AIProviderFactory:
    """Resolves the active `AI_SERVICE_PROVIDER` setting to concrete adapters."""

    def __init__(self, provider: str = "mock"):
        self.provider = provider

    def speech_to_text(self) -> ISpeechToTextProvider:
        if self.provider == "openai":
            from apps.ai.providers.speech.whisper_provider import WhisperSpeechToTextProvider

            return WhisperSpeechToTextProvider()
        from apps.ai.providers.speech.mock_provider import MockSpeechToTextProvider

        return MockSpeechToTextProvider()

    def communication_analysis(self) -> ICommunicationAnalysisProvider:
        # Rule-based; identical regardless of provider setting today, but
        # kept behind the factory so a future LLM-graded variant can be
        # swapped in for `openai` without touching callers.
        from apps.ai.providers.speech.mock_provider import MockCommunicationAnalysisProvider

        return MockCommunicationAnalysisProvider()

    def emotion_detection(self) -> IEmotionDetectionProvider:
        if self.provider != "mock":
            from apps.ai.providers.emotion.deepface_provider import DeepFaceEmotionDetectionProvider

            return DeepFaceEmotionDetectionProvider()
        from apps.ai.providers.emotion.mock_provider import MockEmotionDetectionProvider

        return MockEmotionDetectionProvider()

    def eye_contact_tracking(self) -> IEyeContactTrackingProvider:
        if self.provider != "mock":
            from apps.ai.providers.eye_tracking.mediapipe_provider import MediaPipeEyeContactProvider

            return MediaPipeEyeContactProvider()
        from apps.ai.providers.eye_tracking.mock_provider import MockEyeContactTrackingProvider

        return MockEyeContactTrackingProvider()

    def question_generation(self) -> IQuestionGenerationProvider:
        if self.provider == "openai":
            from apps.ai.providers.llm.openai_question_generator import OpenAIQuestionGenerationProvider

            return OpenAIQuestionGenerationProvider()
        from apps.ai.providers.llm.mock_question_generator import MockQuestionGenerator

        return MockQuestionGenerator()

    def feedback_generation(self) -> IFeedbackGenerationProvider:
        if self.provider == "openai":
            from apps.ai.providers.llm.openai_feedback_generator import OpenAIFeedbackGenerationProvider

            return OpenAIFeedbackGenerationProvider()
        from apps.ai.providers.llm.mock_feedback_generator import MockFeedbackGenerator

        return MockFeedbackGenerator()

    def resume_extraction(self) -> IResumeExtractionProvider:
        if self.provider == "openai":
            from apps.resume.providers.openai_extractor import OpenAIResumeExtractionProvider

            return OpenAIResumeExtractionProvider()
        if self.provider == "gemini":
            from apps.resume.providers.gemini_extractor import GeminiResumeExtractor

            return GeminiResumeExtractor()
        from apps.resume.providers.mock_extractor import MockResumeExtractor

        return MockResumeExtractor()

    def realtime_voice(self) -> IRealtimeVoiceProvider:
        if self.provider == "ultravox":
            from apps.ai.providers.realtime_voice.ultravox_provider import UltravoxRealtimeVoiceProvider

            return UltravoxRealtimeVoiceProvider()
        from apps.ai.providers.realtime_voice.mock_provider import MockRealtimeVoiceProvider

        return MockRealtimeVoiceProvider()
