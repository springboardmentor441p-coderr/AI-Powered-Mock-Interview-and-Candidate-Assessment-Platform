import json
from typing import Any, cast

from django.conf import settings
from django.shortcuts import get_object_or_404
from rest_framework import status
from rest_framework.permissions import AllowAny
from rest_framework.request import Request
from rest_framework.views import APIView

from core.permissions import IsCandidate
from core.responses import APIResponse

from apps.interview.api.serializers.interview_serializer import (
    AppendTranscriptTurnSerializer, ConversationTurnSerializer, CreateRealtimeSessionSerializer,
    RealtimeSessionDetailSerializer,
)
from apps.interview.models import InterviewSession, InterviewTemplate
from apps.interview.selectors.session_selector import get_owned_session_or_404


class SessionRealtimeCreateView(APIView):
    """POST /api/interview/realtime/sessions/create/ - realtime counterpart to SessionCreateView."""

    permission_classes = [IsCandidate]

    def post(self, request: Request, *args: Any, **kwargs: Any):
        from core.container import container
        from apps.resume.selectors.resume_selector import get_primary_processed_resume

        serializer = CreateRealtimeSessionSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = cast(dict[str, Any], serializer.validated_data)

        template = None
        if data.get("template_id"):
            template = InterviewTemplate.objects.filter(pk=data["template_id"], is_active=True).first()

        resume = None
        if data.get("use_primary_resume", True):
            try:
                resume = get_primary_processed_resume(candidate=request.user)
            except Exception:  # noqa: BLE001
                pass

        session = container.session_service().create_realtime_session(
            candidate=request.user,
            interview_type=data["interview_type"],
            domain=data["domain"],
            difficulty=data["difficulty"],
            topic_count=data["topic_count"],
            template=template,
            resume=resume,
        )
        return APIResponse.created(data=RealtimeSessionDetailSerializer(session).data)


class SessionRealtimeStartView(APIView):
    """
    POST /api/interview/realtime/sessions/<session_id>/start/

    Creates the Ultravox call and hands back `call_join_url` for the
    frontend to join directly with the Ultravox client SDK - no audio
    passes through this backend.
    """

    permission_classes = [IsCandidate]

    def post(self, request: Request, session_id: str, *args: Any, **kwargs: Any):
        from core.container import container

        session = get_owned_session_or_404(candidate=request.user, session_id=session_id)
        session = container.interview_orchestrator().start_realtime_session(session=session)
        return APIResponse.success(data=RealtimeSessionDetailSerializer(session).data)


class SessionRealtimeToolAskNextQuestionView(APIView):
    """
    POST /api/interview/realtime/sessions/<session_id>/tools/ask-next-question/

    Called *by Ultravox*, mid-call, whenever the model invokes the
    `ask_next_question` custom tool - not by the frontend or the
    candidate. Authenticated with a shared secret rather than session
    auth, since the caller is a server-to-server webhook.
    """

    permission_classes = [AllowAny]

    def post(self, request: Request, session_id: str, *args: Any, **kwargs: Any):
        from core.container import container

        provided_secret = request.headers.get("X-Tool-Secret", "")
        if not settings.ULTRAVOX_TOOL_SHARED_SECRET or provided_secret != settings.ULTRAVOX_TOOL_SHARED_SECRET:
            return APIResponse.error(message="Invalid tool credentials.", http_status=status.HTTP_401_UNAUTHORIZED)

        session = get_object_or_404(InterviewSession, pk=session_id)
        result_text = container.interview_orchestrator().handle_ask_next_question(
            session=session, arguments=cast(dict, request.data) if request.data else {},
        )
        return APIResponse.success(data={"result": result_text})


class SessionRealtimeAccountWebhookView(APIView):
    """
    POST /api/interview/realtime/webhooks/ultravox/

    Single shared endpoint for Ultravox's account-level lifecycle
    webhooks (call.started / call.joined / call.ended). Routes to a
    session via the call_id embedded in the payload, and verifies the
    HMAC signature per https://docs.ultravox.ai/guides/webhooks.
    """

    permission_classes = [AllowAny]

    def post(self, request: Request, *args: Any, **kwargs: Any):
        from core.container import container
        from apps.ai.providers.realtime_voice.ultravox_provider import UltravoxRealtimeVoiceProvider

        timestamp = request.headers.get("X-Ultravox-Webhook-Timestamp", "")
        signature = request.headers.get("X-Ultravox-Webhook-Signature", "")
        secret = settings.ULTRAVOX_WEBHOOK_SECRET
        if secret:
            valid = UltravoxRealtimeVoiceProvider.verify_webhook_signature(
                body=request.body, timestamp=timestamp, signature_header=signature, secret=secret,
            )
            if not valid:
                return APIResponse.error(message="Invalid webhook signature.", http_status=status.HTTP_401_UNAUTHORIZED)

        payload: dict[str, Any] = json.loads(request.body or b"{}")
        call_id: str = payload.get("call", {}).get("callId", "")
        session = InterviewSession.objects.filter(call_id=call_id).first()
        if session is None:
            return APIResponse.success(data={}, http_status=status.HTTP_204_NO_CONTENT)

        event_type: str = payload.get("event", "unknown").replace(".", "_")
        container.interview_orchestrator().handle_lifecycle_event(
            session=session, event_type=event_type, raw_payload=payload,
        )
        return APIResponse.success(data={}, http_status=status.HTTP_204_NO_CONTENT)


class SessionRealtimeTranscriptView(APIView):
    """
    GET  /api/interview/realtime/sessions/<session_id>/transcript/  - poll turns so far
    POST /api/interview/realtime/sessions/<session_id>/transcript/  - append a turn observed
         client-side via the Ultravox SDK (including barge-in detection)
    """

    permission_classes = [IsCandidate]

    def get(self, request: Request, session_id: str, *args: Any, **kwargs: Any):
        session = get_owned_session_or_404(candidate=request.user, session_id=session_id)
        turns = session.turns.order_by("order")  # type: ignore[attr-defined]
        return APIResponse.success(data=ConversationTurnSerializer(turns, many=True).data)

    def post(self, request: Request, session_id: str, *args: Any, **kwargs: Any):
        from core.container import container

        serializer = AppendTranscriptTurnSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        session = get_owned_session_or_404(candidate=request.user, session_id=session_id)

        vd = cast(dict[str, Any], serializer.validated_data)
        turn = container.interview_orchestrator().record_transcript_turn(
            session=session,
            speaker=vd["speaker"],
            text=vd["text"],
            turn_type=vd.get("turn_type", "answer"),
            started_at_ms=vd.get("started_at_ms"),
            ended_at_ms=vd.get("ended_at_ms"),
            was_interrupted=vd.get("was_interrupted", False),
        )
        return APIResponse.created(data=ConversationTurnSerializer(turn).data)
