# ======================================================
# SmartHire AI - Deepgram Transcription Service
# deepgram_service.py
# ======================================================

import os
import time
import requests
from dotenv import load_dotenv

# ------------------------------------------------------
# Load environment variables
# ------------------------------------------------------

load_dotenv()

DEEPGRAM_API_KEY = os.getenv("DEEPGRAM_API_KEY")


# ======================================================
# TRANSCRIBE AUDIO
# ======================================================

def transcribe_audio(audio_path):

    print("======================================")
    print("🎤 DEEPGRAM TRANSCRIPTION")
    print("======================================")

    print(
        "📁 Audio file:",
        audio_path
    )

    # --------------------------------------------------
    # Check API key
    # --------------------------------------------------

    if not DEEPGRAM_API_KEY:

        raise Exception(
            "DEEPGRAM_API_KEY is missing from .env"
        )

    # --------------------------------------------------
    # Check audio file
    # --------------------------------------------------

    if not os.path.exists(audio_path):

        raise Exception(
            f"Audio file not found: {audio_path}"
        )

    file_size = os.path.getsize(audio_path)

    print(
        "📦 Audio file size:",
        file_size,
        "bytes"
    )

    if file_size == 0:

        raise Exception(
            "Audio file is empty"
        )

    # --------------------------------------------------
    # Deepgram API
    # --------------------------------------------------

    url = (
        "https://api.deepgram.com/v1/listen"
        "?model=nova-3"
        "&smart_format=true"
        "&language=en"
        "&utterances=true"
        "&filler_words=true"
    )

    headers = {

        "Authorization":
            f"Token {DEEPGRAM_API_KEY}",

        "Content-Type":
            "audio/webm"
    }

    # --------------------------------------------------
    # Retry configuration
    # --------------------------------------------------

    max_attempts = 4

    last_error = None

    # ==================================================
    # DEEPGRAM REQUEST
    # ==================================================

    for attempt in range(
        1,
        max_attempts + 1
    ):

        print(
            f"🌐 Deepgram attempt "
            f"{attempt}/{max_attempts}"
        )

        try:

            # ------------------------------------------
            # Read audio
            # ------------------------------------------

            with open(
                audio_path,
                "rb"
            ) as audio:

                audio_data = audio.read()

            print(
                "📦 Bytes sent to Deepgram:",
                len(audio_data)
            )

            if not audio_data:

                raise Exception(
                    "Audio data is empty before sending to Deepgram."
                )

            # ------------------------------------------
            # Send request
            # ------------------------------------------

            response = requests.post(

                url,

                headers=headers,

                data=audio_data,

                timeout=(30, 180)
            )

            print(
                "🌐 Deepgram status:",
                response.status_code
            )

            # ==================================================
            # SUCCESS
            # ==================================================

            if response.status_code == 200:

                try:

                    result = response.json()

                except Exception as error:

                    raise Exception(
                        "Deepgram returned invalid JSON: "
                        + str(error)
                    )

                print(
                    "========== DEEPGRAM RESPONSE =========="
                )

                print(result)

                print(
                    "========================================"
                )

                # ------------------------------------------
                # Metadata
                # ------------------------------------------

                metadata = (
                    result.get(
                        "metadata",
                        {}
                    )
                )

                dg_duration = (
                    metadata.get(
                        "duration"
                    )
                )

                if dg_duration is not None:

                    print(
                        "⏱️ Deepgram detected duration:",
                        dg_duration,
                        "seconds"
                    )

                # ------------------------------------------
                # Get results
                # ------------------------------------------

                results = (
                    result.get(
                        "results",
                        {}
                    )
                )

                channels = (
                    results.get(
                        "channels",
                        []
                    )
                )

                if not channels:

                    print(
                        "⚠️ Deepgram returned no channels."
                    )

                    print(
                        "Full response:",
                        result
                    )

                    return ""

                # ------------------------------------------
                # Get alternatives
                # ------------------------------------------

                alternatives = (
                    channels[0].get(
                        "alternatives",
                        []
                    )
                )

                if not alternatives:

                    print(
                        "⚠️ Deepgram returned no alternatives."
                    )

                    return ""

                # ------------------------------------------
                # Get transcript
                # ------------------------------------------

                transcript = (
                    alternatives[0].get(
                        "transcript",
                        ""
                    )
                )

                transcript = (
                    str(
                        transcript or ""
                    ).strip()
                )

                print(
                    "📝 FINAL TRANSCRIPT:",
                    transcript
                )

                # ==================================================
                # IMPORTANT: EMPTY TRANSCRIPT
                # ==================================================

                if not transcript:

                    print(
                        "⚠️ Deepgram returned HTTP 200 "
                        "but transcript is empty."
                    )

                    # --------------------------------------
                    # Show useful debugging information
                    # --------------------------------------

                    try:

                        detected_channels = len(
                            channels
                        )

                        print(
                            "🔎 Channels:",
                            detected_channels
                        )

                    except Exception:

                        pass

                    print(
                        "🔎 Deepgram metadata:",
                        metadata
                    )

                    print(
                        "🔎 Deepgram results:",
                        results
                    )

                    # Don't treat this as a server failure.
                    # Return empty transcript so the existing
                    # speech_v2.js flow can ask the candidate
                    # to answer again.
                    return ""

                # ------------------------------------------
                # Successful transcript
                # ------------------------------------------

                return transcript

            # ==================================================
            # TEMPORARY ERRORS
            # ==================================================

            if response.status_code in (
                429,
                500,
                502,
                503,
                504
            ):

                print(
                    "⚠️ Temporary Deepgram error:"
                )

                print(
                    response.text[:2000]
                )

                last_error = (
                    f"Deepgram HTTP "
                    f"{response.status_code}"
                )

                if attempt < max_attempts:

                    wait_time = (
                        2 ** (attempt - 1)
                    )

                    print(
                        f"⏳ Retrying in "
                        f"{wait_time} seconds..."
                    )

                    time.sleep(
                        wait_time
                    )

                    continue

                break

            # ==================================================
            # AUTHENTICATION ERROR
            # ==================================================

            if response.status_code in (
                401,
                403
            ):

                raise Exception(
                    "Deepgram authentication failed. "
                    "Check DEEPGRAM_API_KEY in your .env file."
                )

            # ==================================================
            # BAD REQUEST
            # ==================================================

            if response.status_code == 400:

                raise Exception(
                    "Deepgram rejected the audio request: "
                    + response.text[:2000]
                )

            # ==================================================
            # OTHER ERROR
            # ==================================================

            raise Exception(
                f"Deepgram error "
                f"{response.status_code}: "
                f"{response.text[:2000]}"
            )

        # ==================================================
        # SSL ERROR
        # ==================================================

        except requests.exceptions.SSLError as error:

            last_error = error

            print(
                "⚠️ Deepgram SSL error:"
            )

            print(
                repr(error)
            )

            if attempt < max_attempts:

                wait_time = (
                    2 ** (attempt - 1)
                )

                print(
                    f"⏳ SSL retry in "
                    f"{wait_time} seconds..."
                )

                time.sleep(
                    wait_time
                )

                continue

        # ==================================================
        # CONNECTION ERROR
        # ==================================================

        except requests.exceptions.ConnectionError as error:

            last_error = error

            print(
                "⚠️ Deepgram connection error:"
            )

            print(
                repr(error)
            )

            if attempt < max_attempts:

                wait_time = (
                    2 ** (attempt - 1)
                )

                print(
                    f"⏳ Connection retry in "
                    f"{wait_time} seconds..."
                )

                time.sleep(
                    wait_time
                )

                continue

        # ==================================================
        # TIMEOUT
        # ==================================================

        except requests.exceptions.Timeout as error:

            last_error = error

            print(
                "⚠️ Deepgram timeout:"
            )

            print(
                repr(error)
            )

            if attempt < max_attempts:

                wait_time = (
                    2 ** (attempt - 1)
                )

                print(
                    f"⏳ Timeout retry in "
                    f"{wait_time} seconds..."
                )

                time.sleep(
                    wait_time
                )

                continue

        # ==================================================
        # OTHER REQUEST ERROR
        # ==================================================

        except requests.exceptions.RequestException as error:

            last_error = error

            print(
                "⚠️ Deepgram request error:"
            )

            print(
                repr(error)
            )

            if attempt < max_attempts:

                wait_time = (
                    2 ** (attempt - 1)
                )

                print(
                    f"⏳ Request retry in "
                    f"{wait_time} seconds..."
                )

                time.sleep(
                    wait_time
                )

                continue

    # ==================================================
    # ALL ATTEMPTS FAILED
    # ==================================================

    raise Exception(
        "Deepgram transcription failed "
        f"after {max_attempts} attempts. "
        f"Last error: {last_error}"
    )