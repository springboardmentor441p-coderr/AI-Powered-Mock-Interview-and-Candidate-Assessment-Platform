print("RUNNING MAIN FROM:", __file__)

# ======================================================
# IMPORTS
# ======================================================

import os
import time
import shutil

from fastapi import (
    FastAPI,
    Depends,
    UploadFile,
    File,
    HTTPException,
    Request
)

from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from sqlalchemy.orm import Session

from database import engine, SessionLocal

from models import (
    Base,
    User,
    Interview,
    InterviewAnswer
)

from schemas import UserCreate, UserLogin

from auth import (
    hash_password,
    verify_password
)

from resume_parser import extract_text
from ai_resume_parser import extract_resume_details
from ats_score import calculate_score
from job_matcher import recommend_jobs
from skill_gap import analyze_skill_gap
from dashboard import get_dashboard_stats

from question_generator import (
    generate_followup,
    generate_questions
)

from groq_service import evaluate_interview

from deepgram_service import transcribe_audio

from tts_service import generate_ai_voice

from interview_session import get_questions


# ======================================================
# DATABASE
# ======================================================

Base.metadata.create_all(bind=engine)


# ======================================================
# FASTAPI APP
# ======================================================

app = FastAPI(
    title="SmartHire AI Backend",
    version="1.0"
)


# ======================================================
# CORS
# ======================================================

app.add_middleware(
    CORSMiddleware,

    allow_origins=[
        "http://127.0.0.1:5500",
        "http://localhost:5500"
    ],

    allow_credentials=True,

    allow_methods=["*"],

    allow_headers=["*"]
)


# ======================================================
# STATIC FILES
# ======================================================

app.mount(
    "/assets",
    StaticFiles(
        directory="../frontend/assets"
    ),
    name="assets"
)


app.mount(
    "/interview_audio",
    StaticFiles(
        directory="interview_audio"
    ),
    name="interview_audio"
)


# ======================================================
# TEMPLATES
# ======================================================

templates = Jinja2Templates(
    directory="templates"
)


# ======================================================
# DATABASE DEPENDENCY
# ======================================================

def get_db():

    db = SessionLocal()

    try:

        yield db

    finally:

        db.close()


# ======================================================
# START INTERVIEW
# ======================================================

@app.post("/start_interview")
def start_interview(
    data: dict,
    db: Session = Depends(get_db)
):

    user_id = data.get("user_id")

    resume_filename = data.get(
        "resume_filename"
    )

    interview = Interview(

        user_id=user_id,

        resume_filename=resume_filename
    )

    db.add(interview)

    db.commit()

    db.refresh(interview)

    print("================================")
    print("🎯 NEW INTERVIEW STARTED")
    print("Interview ID:", interview.id)
    print("User ID:", user_id)
    print("================================")

    return {

        "message":
            "Interview started successfully",

        "interview_id":
            interview.id
    }


# ======================================================
# HOME
# ======================================================

@app.get("/")
def home():

    return FileResponse(
        os.path.join(
            "templates",
            "index.html"
        )
    )


# ======================================================
# LOGIN PAGE
# ======================================================

@app.get(
    "/login_page",
    response_class=HTMLResponse
)
def login_page():

    with open(
        "../frontend/pages/login.html",
        "r",
        encoding="utf-8"
    ) as f:

        return HTMLResponse(
            content=f.read()
        )


# ======================================================
# RESUME UPLOAD PAGE
# ======================================================

@app.get(
    "/resume_upload",
    response_class=HTMLResponse
)
def resume_upload():

    with open(
        "../frontend/pages/resume_upload.html",
        "r",
        encoding="utf-8"
    ) as f:

        return HTMLResponse(
            content=f.read()
        )


# ======================================================
# INTERVIEW PAGE
# ======================================================

@app.get(
    "/interview",
    response_class=HTMLResponse
)
def interview():

    with open(
        "../frontend/pages/interview.html",
        "r",
        encoding="utf-8"
    ) as f:

        return HTMLResponse(
            content=f.read()
        )


# ======================================================
# INTERVIEW V2 PAGE
# ======================================================

@app.get(
    "/interview_v2",
    response_class=HTMLResponse
)
def interview_v2():

    with open(
        "../frontend/pages/interview_v2.html",
        "r",
        encoding="utf-8"
    ) as f:

        return HTMLResponse(
            content=f.read()
        )


# ======================================================
# INTERVIEW V3 PAGE
# ======================================================

@app.get(
    "/interview_v3",
    response_class=HTMLResponse
)
def interview_v3():

    with open(
        "../frontend/pages/interview_v3.html",
        "r",
        encoding="utf-8"
    ) as f:

        return HTMLResponse(
            content=f.read()
        )


# ======================================================
# REGISTER
# ======================================================

@app.post("/register")
def register(
    user: UserCreate,
    db: Session = Depends(get_db)
):

    existing_user = (
        db.query(User)
        .filter(
            User.email == user.email
        )
        .first()
    )

    if existing_user:

        raise HTTPException(
            status_code=400,
            detail="Email already registered"
        )

    hashed_pwd = hash_password(
        user.password
    )

    new_user = User(

        name=user.name,

        email=user.email,

        password=hashed_pwd,

        role=user.role
    )

    db.add(new_user)

    db.commit()

    db.refresh(new_user)

    return {

        "message":
            "User Registered Successfully!"
    }


# ======================================================
# LOGIN
# ======================================================

@app.post("/login")
def login(
    user: UserLogin,
    db: Session = Depends(get_db)
):

    db_user = (
        db.query(User)
        .filter(
            User.email == user.email
        )
        .first()
    )

    if not db_user:

        raise HTTPException(
            status_code=404,
            detail="User not found"
        )

    if not verify_password(
        user.password,
        db_user.password
    ):

        raise HTTPException(
            status_code=401,
            detail="Invalid Password"
        )

    return {

        "message":
            "Login Successful",

        "user": {

            "id":
                db_user.id,

            "name":
                db_user.name,

            "email":
                db_user.email,

            "role":
                db_user.role
        }
    }


# ======================================================
# UPLOAD RESUME
# ======================================================

@app.post("/upload_resume")
async def upload_resume(
    file: UploadFile = File(...)
):

    if not file.filename.endswith(
        ".pdf"
    ):

        raise HTTPException(
            status_code=400,
            detail="Only PDF files are allowed"
        )

    text = extract_text(
        file.file
    )

    print(
        "TEXT:",
        text[:300]
    )

    details = extract_resume_details(
        text
    )

    print(
        "DETAILS:",
        details
    )

    ats = calculate_score(
        details
    )

    print(
        "ATS:",
        ats
    )

    recommended_jobs = recommend_jobs(
        details.get(
            "skills",
            []
        )
    )

    interview_questions = generate_questions(
        details
    )

    print(
        "JOBS:",
        recommended_jobs
    )

    return {

        "filename":
            file.filename,

        "resume_data":
            details,

        "ats_score":
            ats["score"],

        "ats_feedback":
            ats["feedback"],

        "recommended_jobs":
            recommended_jobs,

        "interview_questions":
            interview_questions,

        "raw_text":
            text
    }


# ======================================================
# SKILL GAP
# ======================================================

@app.post("/skill_gap")
def skill_gap_analysis(
    data: dict
):

    user_skills = data.get(
        "skills",
        []
    )

    target_job = data.get(
        "target_job",
        ""
    )

    result = analyze_skill_gap(
        user_skills,
        target_job
    )

    return result


# ======================================================
# DASHBOARD
# ======================================================

@app.get("/dashboard")
def dashboard(
    db: Session = Depends(get_db)
):

    stats = get_dashboard_stats(
        db
    )

    return stats


# ======================================================
# CANDIDATE DASHBOARD
# ======================================================

@app.get(
    "/candidate_dashboard/{user_id}"
)
def candidate_dashboard(
    user_id: int,
    db: Session = Depends(get_db)
):

    interview = (

        db.query(Interview)

        .filter(
            Interview.user_id ==
            user_id
        )

        .order_by(
            Interview.created_at.desc()
        )

        .first()
    )

    if not interview:

        return {

            "message":
                "No interview found",

            "interview":
                None
        }

    return {

        "interview": {

            "id":
                interview.id,

            "resume_filename":
                interview.resume_filename,

            "overall_score":
                interview.overall_score,

            "communication":
                interview.communication,

            "technical":
                interview.technical,

            "confidence":
                interview.confidence,

            "hr_skills":
                interview.hr_skills,

            "behavioral":
                interview.behavioral,

            "problem_solving":
                interview.problem_solving,

            "recommendation":
                interview.recommendation,

            "strengths":
                interview.strengths,

            "improvements":
                interview.improvements,

            "created_at":
                interview.created_at
        }
    }


# ======================================================
# SAVE ANSWER
# ======================================================

@app.post("/save_answer")
def save_answer(
    data: dict,
    db: Session = Depends(get_db)
):

    print("================================")
    print("💾 SAVE ANSWER REQUEST")
    print("================================")

    try:

        interview_id = data.get("interview_id")
        question_number = data.get("question_number")
        question = data.get("question")
        answer = data.get("answer")

        ai_audio_file = data.get("ai_audio_file")
        candidate_audio_file = data.get("candidate_audio_file")

        print("Interview ID:", interview_id)
        print("Question Number:", question_number)
        print("Question:", question)
        print("Answer:", answer)

        # ---------------------------------------------
        # Validation
        # ---------------------------------------------

        if interview_id is None:
            raise HTTPException(
                status_code=400,
                detail="interview_id is required"
            )

        if question_number is None:
            raise HTTPException(
                status_code=400,
                detail="question_number is required"
            )

        if not question:
            raise HTTPException(
                status_code=400,
                detail="question is required"
            )

        if not answer:
            raise HTTPException(
                status_code=400,
                detail="answer is required"
            )

        try:
            interview_id = int(interview_id)
            question_number = int(question_number)
        except (TypeError, ValueError):
            raise HTTPException(
                status_code=400,
                detail="interview_id and question_number must be integers"
            )

        # ---------------------------------------------
        # Check interview
        # ---------------------------------------------

        interview = (
            db.query(Interview)
            .filter(
                Interview.id == interview_id
            )
            .first()
        )

        if not interview:
            raise HTTPException(
                status_code=404,
                detail=f"Interview {interview_id} not found"
            )

        # ---------------------------------------------
        # Prevent exact duplicate answer
        # ---------------------------------------------

        existing_answer = (
            db.query(InterviewAnswer)
            .filter(
                InterviewAnswer.interview_id == interview_id,
                InterviewAnswer.question_number == question_number,
                InterviewAnswer.question == str(question),
                InterviewAnswer.answer == str(answer)
            )
            .first()
        )

        if existing_answer:

            print("⚠️ Duplicate answer detected.")
            print("Existing Answer ID:", existing_answer.id)

            return {
                "message": "Answer already saved",
                "answer_id": existing_answer.id,
                "duplicate": True
            }

        # ---------------------------------------------
        # Create answer
        # ---------------------------------------------

        interview_answer = InterviewAnswer(
            interview_id=interview_id,
            question_number=question_number,
            question=str(question),
            answer=str(answer),
            ai_audio_file=ai_audio_file,
            candidate_audio_file=candidate_audio_file
        )

        db.add(interview_answer)

        db.commit()

        db.refresh(interview_answer)

        print("✅ ANSWER SAVED SUCCESSFULLY")
        print("Answer ID:", interview_answer.id)
        print("================================")

        return {
            "message": "Answer saved successfully",
            "answer_id": interview_answer.id,
            "duplicate": False
        }

    except HTTPException:

        db.rollback()
        raise

    except Exception as error:

        db.rollback()

        print("================================")
        print("❌ SAVE ANSWER DATABASE ERROR")
        print(repr(error))
        print("================================")

        raise HTTPException(
            status_code=500,
            detail=f"Database error while saving answer: {str(error)}"
        )
@app.get("/check_answers/{interview_id}")
def check_answers(
    interview_id: int,
    db: Session = Depends(get_db)
):

    print("================================")
    print("🔍 CHECKING INTERVIEW ANSWERS")
    print("Interview ID:", interview_id)
    print("================================")

    answers = (
        db.query(InterviewAnswer)
        .filter(
            InterviewAnswer.interview_id == interview_id
        )
        .order_by(
            InterviewAnswer.question_number.asc()
        )
        .all()
    )

    print(
        "📝 Answers found:",
        len(answers)
    )

    return {
        "interview_id": interview_id,
        "answer_count": len(answers),
        "answers": [
            {
                "id": item.id,
                "question_number": item.question_number,
                "question": item.question,
                "answer": item.answer
            }
            for item in answers
        ]
    }



# ======================================================
# TRANSCRIBE AUDIO
# ======================================================

@app.post("/transcribe")
async def transcribe(
    audio: UploadFile = File(...)
):

    print("================================")
    print("🔥🔥🔥 TRANSCRIBE ENDPOINT CALLED 🔥🔥🔥")
    print("================================")

    try:

        # --------------------------------------
        # Backend folder
        # --------------------------------------

        backend_folder = os.path.dirname(
            os.path.abspath(__file__)
        )

        # --------------------------------------
        # Audio folder
        # --------------------------------------

        audio_folder = os.path.join(
            backend_folder,
            "interview_audio"
        )

        os.makedirs(
            audio_folder,
            exist_ok=True
        )

        print(
            "📁 Audio folder:",
            audio_folder
        )

        # --------------------------------------
        # Unique filename
        # --------------------------------------

        filename = (
            f"candidate_"
            f"{int(time.time() * 1000)}"
            f".webm"
        )

        file_path = os.path.join(
            audio_folder,
            filename
        )

        print(
            "📁 Saving audio to:",
            file_path
        )

        # --------------------------------------
        # Read uploaded audio
        # --------------------------------------

        contents = await audio.read()

        print(
            "📦 Audio received:",
            len(contents),
            "bytes"
        )

        if len(contents) == 0:

            raise HTTPException(
                status_code=400,
                detail=
                "Received empty audio file."
            )

        # --------------------------------------
        # Save candidate audio
        # --------------------------------------

        with open(
            file_path,
            "wb"
        ) as buffer:

            buffer.write(contents)

        print(
            "🎤 Candidate audio saved successfully"
        )

        # --------------------------------------
        # Deepgram transcription
        # --------------------------------------

        transcript = transcribe_audio(
            file_path
        )

        print(
            "📝 Transcript:",
            transcript
        )

        # --------------------------------------
        # Return
        # --------------------------------------

        return {

            "message":
                "Audio saved successfully",

            "transcript":
                transcript,

            "audio_file":
                filename
        }

    except HTTPException:

        raise

    except Exception as error:

        print(
            "❌ TRANSCRIBE ERROR:",
            repr(error)
        )

        raise HTTPException(
            status_code=500,
            detail=str(error)
        )


# ======================================================
# GENERATE AI VOICE
# ======================================================

@app.post("/generate_voice")
async def generate_voice(
    data: dict
):

    text = data.get(
        "text",
        ""
    )

    if not text:

        raise HTTPException(
            status_code=400,
            detail="Text is required"
        )

    filename = (
        f"ai_question_"
        f"{int(time.time() * 1000)}"
        f".mp3"
    )

    try:

        audio_file = await generate_ai_voice(
            text,
            filename
        )

        return {

            "message":
                "AI voice generated successfully",

            "audio_file":
                audio_file
        }

    except Exception as error:

        print(
            "❌ TTS ERROR:",
            repr(error)
        )

        raise HTTPException(
            status_code=500,
            detail=str(error)
        )


# ======================================================
# INTERVIEW QUESTIONS
# ======================================================

@app.get("/interview_questions")
def interview_questions():

    return {

        "questions":
            get_questions()
    }


# ======================================================
# EVALUATE INTERVIEW
# ======================================================

@app.post("/evaluate_interview")
def evaluate(
    data: dict,
    db: Session = Depends(get_db)
):

    print("================================")
    print("🤖 EVALUATING INTERVIEW")
    print("================================")

    interview_id = data.get(
        "interview_id"
    )

    print(
        "Interview ID:",
        interview_id
    )

    # --------------------------------------
    # Validate interview ID
    # --------------------------------------

    if not interview_id:

        raise HTTPException(
            status_code=400,
            detail="interview_id is required"
        )

    try:

        interview_id = int(
            interview_id
        )

    except (
        TypeError,
        ValueError
    ):

        raise HTTPException(
            status_code=400,
            detail="Invalid interview_id"
        )

    # --------------------------------------
    # Find interview
    # --------------------------------------

    interview = (

        db.query(Interview)

        .filter(
            Interview.id ==
            interview_id
        )

        .first()
    )

    if not interview:

        raise HTTPException(
            status_code=404,
            detail="Interview not found"
        )

    # --------------------------------------
    # Get answers from database
    # --------------------------------------

    interview_answers = (

        db.query(InterviewAnswer)

        .filter(
            InterviewAnswer.interview_id ==
            interview_id
        )

        .order_by(
            InterviewAnswer.question_number.asc()
        )

        .all()
    )

    print(
        "📝 Answers found in database:",
        len(interview_answers)
    )

    # --------------------------------------
    # Validate answers
    # --------------------------------------

    if not interview_answers:

        raise HTTPException(
            status_code=400,
            detail=
            "No interview answers were recorded."
        )

    # --------------------------------------
    # Convert answers
    # --------------------------------------

    answers = []

    for item in interview_answers:

        answers.append({

            "question":
                item.question,

            "answer":
                item.answer
        })

    print(
        "📝 Answers sent to AI:",
        len(answers)
    )

    print(
        "📝 Answer data:",
        answers
    )

    # --------------------------------------
    # Generate AI report
    # --------------------------------------

    report = evaluate_interview(
        answers
    )

    print(
        "========== AI REPORT =========="
    )

    print(
        report
    )

    print(
        "==============================="
    )

    # --------------------------------------
    # Save report
    # --------------------------------------

    interview.overall_score = \
        report.get(
            "overall_score"
        )

    interview.communication = \
        report.get(
            "communication"
        )

    interview.technical = \
        report.get(
            "technical"
        )

    interview.confidence = \
        report.get(
            "confidence"
        )

    interview.hr_skills = \
        report.get(
            "hr_skills"
        )

    interview.behavioral = \
        report.get(
            "behavioral"
        )

    interview.problem_solving = \
        report.get(
            "problem_solving"
        )

    # --------------------------------------
    # Strengths
    # --------------------------------------

    interview.strengths = ", ".join(
        report.get(
            "strengths",
            []
        )
    )

    # --------------------------------------
    # Improvements
    # --------------------------------------

    interview.improvements = ", ".join(
        report.get(
            "improvements",
            []
        )
    )

    # --------------------------------------
    # Recommendation
    # --------------------------------------

    interview.recommendation = \
        report.get(
            "recommendation"
        )

    # --------------------------------------
    # Save PostgreSQL
    # --------------------------------------

    db.commit()

    db.refresh(
        interview
    )

    print(
        "================================"
    )

    print(
        "💾 INTERVIEW REPORT SAVED"
    )

    print(
        "Interview ID:",
        interview.id
    )

    print(
        "Overall Score:",
        interview.overall_score
    )

    print(
        "Recommendation:",
        interview.recommendation
    )

    print(
        "================================"
    )

    return report


# ======================================================
# GENERATE QUESTIONS
# ======================================================

@app.post("/generate_questions")
def generate_ai_questions(
    data: dict
):

    resume = data.get(
        "resume",
        {}
    )

    questions = generate_questions(
        resume
    )

    return {

        "questions":
            questions
    }


# ======================================================
# FOLLOW-UP QUESTION
# ======================================================

@app.post("/followup_question")
def followup_question(
    data: dict
):

    print("================================")
    print("🤖 FOLLOW-UP QUESTION REQUEST")
    print("================================")

    print(
        "DATA:",
        data
    )

    question = str(
        data.get(
            "question"
        ) or ""
    ).strip()

    answer = str(
        data.get(
            "answer"
        ) or ""
    ).strip()

    if not question:

        raise HTTPException(
            status_code=400,
            detail=
            "Question was empty when received by backend."
        )

    if not answer:

        raise HTTPException(
            status_code=400,
            detail=
            "Answer was empty when received by backend."
        )

    try:

        followup = generate_followup(
            question,
            answer
        )

        followup = str(
            followup or ""
        ).strip()

        if not followup:

            raise HTTPException(
                status_code=500,
                detail=
                "AI returned an empty follow-up question."
            )

        print(
            "✅ FOLLOW-UP GENERATED:",
            followup
        )

        return {

            "followup":
                followup
        }

    except HTTPException:

        raise

    except Exception as error:

        print(
            "❌ FOLLOW-UP ERROR:",
            repr(error)
        )

        raise HTTPException(
            status_code=500,
            detail=str(error)
        )


# ======================================================
# CAMERA
# ======================================================

@app.get(
    "/camera",
    response_class=HTMLResponse
)
def camera():

    with open(
        "../frontend/pages/camera.html",
        "r",
        encoding="utf-8"
    ) as f:

        return HTMLResponse(
            content=f.read()
        )