import os
import requests
from dotenv import load_dotenv

load_dotenv()

DEEPGRAM_API_KEY = os.getenv("DEEPGRAM_API_KEY")

AUDIO_FILE = "test_audio.wav.m4a"  # Change this to your audio file name

url = "https://api.deepgram.com/v1/listen"

headers = {
    "Authorization": f"Token {DEEPGRAM_API_KEY}",
    "Content-Type": "audio/mp4"
}

with open(AUDIO_FILE, "rb") as audio:
    response = requests.post(
        url,
        headers=headers,
        data=audio
    )

print("Status Code:", response.status_code)

print(response.text)

if response.status_code == 200:
    result = response.json()

    transcript = result["results"]["channels"][0]["alternatives"][0]["transcript"]

    print("\nTranscript:")
    print(transcript)