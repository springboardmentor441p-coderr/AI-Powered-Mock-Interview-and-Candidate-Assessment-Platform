import os
from dotenv import load_dotenv

load_dotenv()

key = os.getenv("GEMINI_API_KEY")

print("KEY =", repr(key))
print("LENGTH =", len(key))