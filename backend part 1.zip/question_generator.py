import os
import json
import time

from dotenv import load_dotenv
from groq import Groq
from groq import RateLimitError


# ============================================================
# LOAD ENVIRONMENT
# ============================================================

load_dotenv()

GROQ_API_KEY = os.getenv("GROQ_API_KEY")

if not GROQ_API_KEY:
    raise RuntimeError(
        "GROQ_API_KEY is not configured in the .env file."
    )


# ============================================================
# GROQ CLIENT
# ============================================================

client = Groq(
    api_key=GROQ_API_KEY
)


# ============================================================
# MODEL
# ============================================================

MODEL_NAME = "llama-3.3-70b-versatile"


# ============================================================
# GROQ CALL HELPER
# ============================================================

def call_groq(prompt, temperature=0.4):

    try:

        response = client.chat.completions.create(
            model=MODEL_NAME,

            messages=[
                {
                    "role": "user",
                    "content": prompt
                }
            ],

            temperature=temperature,

            # Keep responses reasonably small
            max_tokens=1800
        )

        return response.choices[0].message.content.strip()


    except RateLimitError as error:

        print("❌ GROQ RATE LIMIT ERROR")
        print(error)

        raise RuntimeError(
            "Groq rate limit reached. "
            "Please wait until your Groq limit resets "
            "or use another API/model."
        ) from error


    except Exception as error:

        print("❌ GROQ API ERROR")
        print(error)

        raise RuntimeError(
            f"Groq API error: {str(error)}"
        ) from error


# ============================================================
# CLEAN JSON RESPONSE
# ============================================================

def clean_json_response(text):

    text = text.strip()

    # Remove markdown code fences
    if text.startswith("```json"):
        text = text[7:]

    elif text.startswith("```"):
        text = text[3:]

    if text.endswith("```"):
        text = text[:-3]

    text = text.strip()

    return text


# ============================================================
# GENERATE 15 INTERVIEW QUESTIONS
# ============================================================

def generate_questions(resume):

    print("==========================================")
    print("🤖 GENERATING AI QUESTIONS")
    print("==========================================")


    if not resume:

        raise ValueError(
            "Resume data is empty."
        )


    # --------------------------------------------------------
    # Limit resume length
    # --------------------------------------------------------

    resume_text = str(resume)

    if len(resume_text) > 12000:
        resume_text = resume_text[:12000]


    # --------------------------------------------------------
    # Prompt
    # --------------------------------------------------------

    prompt = f"""
You are an experienced HR interviewer.

Candidate Resume:

{resume_text}

Generate exactly 15 interview questions.

Question distribution:

5 Resume-based questions
3 Technical questions
3 HR questions
2 Behavioral questions
2 Situational questions

Rules:

- Questions must be relevant to the candidate's resume.
- Avoid duplicate questions.
- Keep questions clear and interview-friendly.
- Do not provide answers.
- Do not provide explanations.
- Return ONLY valid JSON.
- The JSON must contain exactly one key named "questions".
- "questions" must contain exactly 15 strings.

Required JSON format:

{{
    "questions": [
        "Question 1",
        "Question 2",
        "Question 3"
    ]
}}
"""


    # --------------------------------------------------------
    # Call Groq
    # --------------------------------------------------------

    text = call_groq(
        prompt,
        temperature=0.4
    )


    print("📥 AI response received.")


    # --------------------------------------------------------
    # Clean response
    # --------------------------------------------------------

    text = clean_json_response(text)


    # --------------------------------------------------------
    # Parse JSON
    # --------------------------------------------------------

    try:

        result = json.loads(text)

    except json.JSONDecodeError as error:

        print("❌ Invalid JSON returned by Groq:")
        print(text)

        raise RuntimeError(
            "AI returned invalid question data."
        ) from error


    # --------------------------------------------------------
    # Get questions
    # --------------------------------------------------------

    questions = result.get("questions", [])


    # --------------------------------------------------------
    # Validate
    # --------------------------------------------------------

    if not isinstance(questions, list):

        raise RuntimeError(
            "AI returned invalid questions format."
        )


    questions = [
        str(question).strip()
        for question in questions
        if str(question).strip()
    ]


    if len(questions) < 15:

        raise RuntimeError(
            f"AI generated only {len(questions)} questions."
        )


    # Keep exactly 15
    questions = questions[:15]


    print(
        f"✅ Generated {len(questions)} questions"
    )


    return questions


# ============================================================
# GENERATE AI FOLLOW-UP QUESTION
# ============================================================

def generate_followup(question, answer):

    print("==========================================")
    print("🤖 GENERATING AI FOLLOW-UP")
    print("==========================================")


    if not question:
        raise ValueError(
            "Previous question is empty."
        )


    if not answer:
        answer = "The candidate did not provide a clear answer."


    # --------------------------------------------------------
    # Limit text
    # --------------------------------------------------------

    question_text = str(question)[:3000]
    answer_text = str(answer)[:5000]


    # --------------------------------------------------------
    # Prompt
    # --------------------------------------------------------

    prompt = f"""
You are an experienced HR interviewer.

Previous Interview Question:

{question_text}

Candidate Answer:

{answer_text}

Generate ONE intelligent follow-up interview question.

Rules:

- If the answer mentions a project, ask a deeper question about that project.
- If the answer mentions a technical skill, ask about that skill.
- If the answer is vague, ask for clarification.
- If the answer is strong, ask a slightly more advanced question.
- Ask exactly ONE question.
- Do not provide an answer.
- Do not provide explanations.
- Return only the question text.
"""


    # --------------------------------------------------------
    # Call Groq
    # --------------------------------------------------------

    result = call_groq(
        prompt,
        temperature=0.3
    )


    # --------------------------------------------------------
    # Clean result
    # --------------------------------------------------------

    result = result.strip()

    result = result.replace(
        "```",
        ""
    ).strip()


    print(
        "✅ Follow-up question generated."
    )


    return result