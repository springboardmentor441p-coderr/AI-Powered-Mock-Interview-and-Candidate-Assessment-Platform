def get_questions():

    return [

        "Tell me about yourself.",

        "Explain your final year project.",

        "Why should we hire you?",

        "What are your strengths?",

        "Where do you see yourself in five years?"

    ]