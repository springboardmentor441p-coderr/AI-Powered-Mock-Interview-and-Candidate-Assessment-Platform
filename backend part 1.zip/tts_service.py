import os
import edge_tts

VOICE = "en-US-AriaNeural"


async def generate_ai_voice(text, filename):
    backend_folder = os.path.dirname(os.path.abspath(__file__))

    audio_folder = os.path.join(
        backend_folder,
        "interview_audio"
    )

    # Create folder if it doesn't exist
    os.makedirs(audio_folder, exist_ok=True)

    file_path = os.path.join(
        audio_folder,
        filename
    )

    print("🤖 Generating AI voice...")
    print("📝 Text:", text)
    print("📁 Saving AI voice:", file_path)

    communicate = edge_tts.Communicate(
        text,
        VOICE
    )

    await communicate.save(file_path)

    print("✅ AI voice saved successfully")

    return filename