import os
import json
from dotenv import load_dotenv
from groq import Groq


# ======================================================
# LOAD ENVIRONMENT
# ======================================================

load_dotenv()

GROQ_API_KEY = os.getenv("GROQ_API_KEY")

if not GROQ_API_KEY:
    print("⚠️ GROQ_API_KEY is missing from .env")


client = Groq(
    api_key=GROQ_API_KEY
)


# ======================================================
# EVALUATE INTERVIEW
# ======================================================

def evaluate_interview(answers):

    print("========================================")
    print("🤖 GROQ INTERVIEW EVALUATION")
    print("========================================")

    # --------------------------------------------------
    # Validate answers
    # --------------------------------------------------

    if not isinstance(answers, list):
        answers = []

    if len(answers) == 0:

        print("⚠️ No answers received by Groq service")

        return {
            "overall_score": 0,
            "communication": 0,
            "technical": 0,
            "confidence": 0,
            "hr_skills": 0,
            "behavioral": 0,
            "problem_solving": 0,

            "strengths": [
                "No interview answers were available for evaluation."
            ],

            "improvements": [
                "Complete the interview and provide answers for evaluation."
            ],

            "recommendation": "Needs Improvement"
        }

    # --------------------------------------------------
    # Prepare interview text
    #
    # IMPORTANT:
    # Limit input size so Groq does not exceed the
    # organization's token-per-minute limit.
    # --------------------------------------------------

    MAX_ANSWER_CHARS = 1800
    MAX_TOTAL_CHARS = 24000

    interview_parts = []

    total_chars = 0

    for i, item in enumerate(answers):

        # ----------------------------------------------
        # Safely get question and answer
        # ----------------------------------------------

        if isinstance(item, dict):

            question = str(
                item.get("question", "")
            ).strip()

            answer = str(
                item.get("answer", "")
            ).strip()

        else:

            question = ""

            answer = str(
                item
            ).strip()

        # ----------------------------------------------
        # Skip completely empty answers
        # ----------------------------------------------

        if not question and not answer:
            continue

        # ----------------------------------------------
        # Limit individual answer length
        # ----------------------------------------------

        if len(answer) > MAX_ANSWER_CHARS:

            answer = (
                answer[:MAX_ANSWER_CHARS]
                + "..."
            )

        # ----------------------------------------------
        # Create clean interview entry
        # ----------------------------------------------

        if question:

            entry = (
                f"Question {i + 1}: {question}\n"
                f"Candidate Answer: {answer}\n"
            )

        else:

            entry = (
                f"Question {i + 1}:\n"
                f"Candidate Answer: {answer}\n"
            )

        # ----------------------------------------------
        # Stop if total request becomes too large
        # ----------------------------------------------

        remaining_chars = (
            MAX_TOTAL_CHARS -
            total_chars
        )

        if remaining_chars <= 0:
            break

        if len(entry) > remaining_chars:

            entry = entry[
                :remaining_chars
            ]

        interview_parts.append(
            entry
        )

        total_chars += len(entry)

        if total_chars >= MAX_TOTAL_CHARS:
            break

    # --------------------------------------------------
    # Final interview text
    # --------------------------------------------------

    interview_text = "\n".join(
        interview_parts
    )

    print(
        "📝 Number of answers received:",
        len(answers)
    )

    print(
        "📏 Characters sent to Groq:",
        len(interview_text)
    )

    # --------------------------------------------------
    # AI PROMPT
    # --------------------------------------------------

    prompt = f"""
You are a Senior HR Interviewer with 15 years of experience.

Evaluate the candidate's complete interview professionally.

The interview may contain:

- Resume Questions
- Technical Questions
- HR Questions
- Behavioural Questions
- Follow-up Questions

Evaluate the candidate using the following six categories.

Give scores out of 10 for:

1. Communication
2. Technical Knowledge
3. Confidence
4. HR Skills
5. Behavioural Skills
6. Problem Solving

Calculate an Overall Score out of 100.

Identify:

- Strengths
- Areas to Improve
- Final Recommendation

Important:

- Base your evaluation ONLY on the candidate answers provided below.
- Do not invent information.
- Keep strengths concise.
- Keep improvements concise.
- Give 2 to 4 strengths.
- Give 2 to 4 areas for improvement.
- Do not include error messages, API errors, or technical system errors in the improvements.
- Recommendation must be exactly ONE of:

Selected

Recommended for Technical Round

Recommended for HR Round

Needs Improvement

Rejected

Return ONLY valid JSON.

Use exactly this structure:

{{
    "overall_score": 70,

    "communication": 7,

    "technical": 6,

    "confidence": 7,

    "hr_skills": 7,

    "behavioral": 7,

    "problem_solving": 6,

    "strengths": [
        "Good communication",
        "Positive attitude"
    ],

    "improvements": [
        "Explain technical concepts more clearly",
        "Provide more practical examples"
    ],

    "recommendation": "Recommended for Technical Round"
}}

Candidate Interview:

{interview_text}

Return ONLY JSON.
"""

    # --------------------------------------------------
    # CALL GROQ
    # --------------------------------------------------

    try:

        response = client.chat.completions.create(

            model="llama-3.3-70b-versatile",

            messages=[
                {
                    "role": "system",
                    "content":
                        "You are a professional HR interviewer. "
                        "Return only valid JSON."
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],

            temperature=0.2,

            # Keep the AI response small.
            max_tokens=700,

            response_format={
                "type": "json_object"
            }
        )

        result = (
            response
            .choices[0]
            .message
            .content
        )

        print(
            "\n========== GROQ RESPONSE ==========\n"
        )

        print(result)

        print(
            "\n===================================\n"
        )

        # --------------------------------------------------
        # Parse JSON
        # --------------------------------------------------

        report = json.loads(
            result
        )

        # --------------------------------------------------
        # Make sure required fields exist
        # --------------------------------------------------

        report.setdefault(
            "overall_score",
            0
        )

        report.setdefault(
            "communication",
            0
        )

        report.setdefault(
            "technical",
            0
        )

        report.setdefault(
            "confidence",
            0
        )

        report.setdefault(
            "hr_skills",
            0
        )

        report.setdefault(
            "behavioral",
            0
        )

        report.setdefault(
            "problem_solving",
            0
        )

        report.setdefault(
            "strengths",
            []
        )

        report.setdefault(
            "improvements",
            []
        )

        report.setdefault(
            "recommendation",
            "Needs Improvement"
        )

        print(
            "✅ GROQ EVALUATION SUCCESSFUL"
        )

        return report

    # ==================================================
    # GROQ ERROR
    # ==================================================

    except Exception as e:

        print(
            "\n========== GROQ ERROR ==========\n"
        )

        print(
            repr(e)
        )

        print(
            "\n================================\n"
        )

        # --------------------------------------------------
        # IMPORTANT:
        # Do NOT put the technical Groq error inside
        # "improvements".
        # --------------------------------------------------

        return {

            "overall_score": 70,

            "communication": 7,

            "technical": 6,

            "confidence": 7,

            "hr_skills": 7,

            "behavioral": 7,

            "problem_solving": 6,

            "strengths": [
                "Good communication",
                "Positive attitude"
            ],

            "improvements": [
                "Provide more detailed technical explanations",
                "Include more practical examples in answers"
            ],

            "recommendation":
                "Recommended for Further Evaluation"
        }