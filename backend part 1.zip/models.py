from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from database import Base
from datetime import datetime


# =========================
# USER TABLE
# =========================

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String)
    email = Column(String, unique=True)
    password = Column(String)
    role = Column(String)

    # One user can have multiple interviews
    interviews = relationship(
        "Interview",
        back_populates="user"
    )


# =========================
# INTERVIEW TABLE
# =========================

class Interview(Base):
    __tablename__ = "interviews"

    id = Column(Integer, primary_key=True, index=True)

    # Candidate/User who attended the interview
    user_id = Column(
        Integer,
        ForeignKey("users.id"),
        nullable=True
    )

    # Resume information
    resume_filename = Column(String, nullable=True)

    # Final interview result
    overall_score = Column(Integer, nullable=True)
    communication = Column(Integer, nullable=True)
    technical = Column(Integer, nullable=True)
    confidence = Column(Integer, nullable=True)
    hr_skills = Column(Integer, nullable=True)
    behavioral = Column(Integer, nullable=True)
    problem_solving = Column(Integer, nullable=True)

    # Final recommendation
    recommendation = Column(String, nullable=True)

    # Strengths and improvements stored as text
    strengths = Column(Text, nullable=True)
    improvements = Column(Text, nullable=True)

    # Interview date/time
    created_at = Column(
        DateTime,
        default=datetime.utcnow
    )

    # Relationship with User
    user = relationship(
        "User",
        back_populates="interviews"
    )

    # One interview can have many answers
    answers = relationship(
        "InterviewAnswer",
        back_populates="interview",
        cascade="all, delete-orphan"
    )


# =========================
# INTERVIEW ANSWERS TABLE
# =========================

class InterviewAnswer(Base):
    __tablename__ = "interview_answers"

    id = Column(Integer, primary_key=True, index=True)

    # Which interview?
    interview_id = Column(
        Integer,
        ForeignKey("interviews.id"),
        nullable=False
    )

    # Question number
    question_number = Column(Integer)

    # Question asked by AI
    question = Column(Text)

    # Candidate's Deepgram transcript
    answer = Column(Text)

    # Saved AI interviewer voice filename
    ai_audio_file = Column(String, nullable=True)

    # Saved candidate voice filename
    candidate_audio_file = Column(String, nullable=True)

    # When this answer was recorded
    created_at = Column(
        DateTime,
        default=datetime.utcnow
    )

    # Relationship with Interview
    interview = relationship(
        "Interview",
        back_populates="answers"
    )