def generate_questions(resume_data):

    questions = []

    # -----------------------
    # Resume Based Questions
    # -----------------------

    questions.append(
        f"Tell me about yourself."
    )

    if resume_data.get("projects"):

        for project in resume_data["projects"]:

            questions.append(
                f"Can you explain your project '{project}'?"
            )

    if resume_data.get("skills"):

        for skill in resume_data["skills"][:5]:

            questions.append(
                f"Rate your knowledge in {skill}."
            )

            questions.append(
                f"Explain one real-world application of {skill}."
            )

    # -----------------------
    # Technical Questions
    # -----------------------

    questions.extend([

        "What is OOPS?",

        "Explain Encapsulation.",

        "Difference between Stack and Queue.",

        "Difference between Process and Thread.",

        "What is REST API?",

        "Explain SQL JOIN.",

        "What is Normalization?",

        "Explain HTTP Status Codes.",

        "Difference between Authentication and Authorization."

    ])

    # -----------------------
    # HR Questions
    # -----------------------

    questions.extend([

        "Why should we hire you?",

        "Tell me about your strengths.",

        "Tell me about your weaknesses.",

        "Where do you see yourself in 5 years?",

        "Why do you want to join our company?"

    ])

    # -----------------------
    # Behavioral Questions
    # -----------------------

    questions.extend([

        "Tell me about a time you handled pressure.",

        "Describe a conflict in your team and how you solved it.",

        "Describe a leadership experience.",

        "Describe a difficult problem you solved.",

        "Tell me about a failure and what you learned."

    ])

    return questions