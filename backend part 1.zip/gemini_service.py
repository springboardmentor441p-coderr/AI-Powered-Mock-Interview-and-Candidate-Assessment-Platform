import os
import json
from dotenv import load_dotenv
from google import genai

# Load environment variables
load_dotenv()

# Read API Key
api_key = os.getenv("GEMINI_API_KEY")

print("Current Directory:", os.getcwd())
print("API KEY Loaded:", "Yes" if api_key else "No")

if not api_key:
    raise ValueError("GEMINI_API_KEY not found in .env file")

print("API KEY:", api_key[:15] + "...")

# Create Gemini Client
client = genai.Client(api_key=api_key)


def evaluate_interview(answers):

    prompt = f"""
You are an experienced HR interviewer.

Evaluate the following interview answers.

Answers:
{answers}

Return ONLY valid JSON in this format:

{{
  "overall_score": 85,
  "communication": 8,
  "technical": 7,
  "confidence": 9,
  "strengths": [
    "Good communication",
    "Confident answers"
  ],
  "improvements": [
    "Explain projects in more detail",
    "Use more technical examples"
  ],
  "recommendation": "Recommended for Technical Round"
}}
"""

    try:

        response = client.models.generate_content(
            model="gemini-2.0-flash",
            contents=prompt
        )

        print("\n========== GEMINI RAW RESPONSE ==========")
        print(response.text)
        print("=========================================\n")

        text = response.text.strip()

        # Remove markdown if Gemini returns it
        text = text.replace("```json", "")
        text = text.replace("```", "")
        text = text.strip()

        print("\n========== CLEAN JSON ==========")
        print(text)
        print("================================\n")

        return json.loads(text)

    except Exception as e:

        print("\n========== GEMINI ERROR ==========")
        print(type(e).__name__)
        print(e)
        print("==================================\n")

        return {
            "overall_score": 0,
            "communication": 0,
            "technical": 0,
            "confidence": 0,
            "strengths": [],
            "improvements": [str(e)],
            "recommendation": "Gemini Error"
        }